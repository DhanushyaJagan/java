package com.cg.project.main;

import com.cg.project.beans.CEmployee;
import com.cg.project.beans.Developer;
import com.cg.project.beans.Employee;
import com.cg.project.beans.PEmployee;
import com.cg.project.beans.SalesManager;

public class MainClass {

	public static void main(String[] args) {
		Employee employee =new Employee(456, 20000, "dhanu", "jagan");
		employee.setCalculatorTotalsalary();
		System.out.println(employee.toString() );
		
		PEmployee pEmployee=new PEmployee(466, 7000, "dhanu", "jagan");
		pEmployee.setCalculatorTotalsalary();
		System.out.println(pEmployee.toString());
		
		CEmployee cEmployee = new CEmployee(345, "JAGAN", "RAMASAMY", 55);
		cEmployee.signcontract();
		cEmployee.setCalculatorTotalsalary();
		System.out.println(cEmployee.toString());
		
		SalesManager salesmanagaer=new SalesManager(234, 9000, "NIMMI", "JAGAN", 23);
		salesmanagaer.salesdone();
		salesmanagaer.setCalculatorTotalsalary();
		System.out.println(salesmanagaer.toString());
		
		Developer developer=new Developer(234, 9000, "DHANU", "MONI", 6);
		developer.setCalculatorTotalsalary();
		System.out.println(developer.toString());
	}

}