package com.cg.project.beans;

public class SalesManager extends PEmployee {
	private int salesAmnt,commission;

	public SalesManager() {
		super();
	}

	//public SalesManager(int employeeId, int basicSalary, String firstName, String secondName) {
	//super(employeeId, basicSalary, firstName, secondName);
	//}

	public SalesManager(int employeeId, int basicSalary, String firstName, String secondName,int salesAmnt) {
		super(employeeId, basicSalary, firstName, secondName);
		this.salesAmnt=salesAmnt;
	}

	public int getSalesAmnt() {
		return salesAmnt;
	}

	public void setSalesAmnt(int salesAmnt) {
		this.salesAmnt = salesAmnt;
	}

	public int getCommission() {
		return commission;
	}

	public void setCommission(int commission) {
		this.commission = commission;
	}
	public void salesdone()
	{
		System.out.println("sales done");
	}

	@Override
	public void setCalculatorTotalsalary() {
		super.setCalculatorTotalsalary();
		this.commission=((1*salesAmnt/100));
	}

	@Override
	public String toString() {
		return super.toString()+", "+"commission="+commission;
	}

}
