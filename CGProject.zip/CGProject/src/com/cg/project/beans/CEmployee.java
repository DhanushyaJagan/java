package com.cg.project.beans;

public class CEmployee extends Employee{
	private int hrs,variablepay;

	public CEmployee() {
		super();
	}

	//public CEmployee(int employeeId,  String firstName,	String secondName) {
	//	super(employeeId, firstName, secondName);
//
	//}
	public CEmployee(int employeeId,  String firstName,	String secondName,int hrs) {
		super(employeeId,firstName, secondName);
		this.hrs=hrs;

	}

	public int getHrs() {
		return hrs;
	}

	public void setHrs(int hrs) {
		this.hrs = hrs;
	}

	public int getVariablepay() {
		return variablepay;
	}

	public void setVariablepay(int variablepay) {
		this.variablepay = variablepay;
	}
	public void signcontract()
	{
		System.out.println("contract signed");
	}

	@Override
	public void setCalculatorTotalsalary() {
		variablepay=getHrs()*1000;
	}

	@Override
	public String toString() {
		return super.toString()+"hrs"+hrs+"variable pay"+variablepay;
	}

}