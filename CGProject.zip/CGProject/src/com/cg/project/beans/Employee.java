package com.cg.project.beans;

public class Employee {
	private int employeeId,basicSalary,totalSalary;
	private String firstName,secondName;
	public Employee() {
		super();
	}

	public Employee(int employeeId, String firstName, String secondName) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.secondName = secondName;
	}
	public Employee(int employeeId, int basicSalary,String firstName, String secondName) {
		super();
		this.employeeId = employeeId;
		this.basicSalary = basicSalary;
		this.firstName = firstName;
		this.secondName = secondName;
	}

	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public int getTotalSalary() {
		return totalSalary;
	}
	public void setTotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSecondName() {
		return secondName;
	}
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
	public void setCalculatorTotalsalary()
	{
		this.totalSalary=getBasicSalary();
	}
	@Override
	public String toString() {
		return "employeeId=" + employeeId + ", basicSalary="
				+ basicSalary + ", totalSalary=" + totalSalary + ", firstName="
				+ firstName + ", secondName=" + secondName ;
	}



}
