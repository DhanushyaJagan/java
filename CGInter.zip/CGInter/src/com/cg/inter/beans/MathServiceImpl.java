package com.cg.inter.beans;

public class MathServiceImpl implements MathService {
	@Override
	public int add(int n1, int n2) {
		int s=n1+n2;
		return s;
	}

	@Override
	public int sub(int n1, int n2) {
		int d=n1-n2;
		return d;
	}


}
