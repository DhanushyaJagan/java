package com.cg.inter.beans;

public interface MathService {
public int add(int n1,int n2);
public int sub(int n1,int n2);

}
