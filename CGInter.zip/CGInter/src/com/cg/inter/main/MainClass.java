package com.cg.inter.main;

import com.cg.inter.beans.MathService;
import com.cg.inter.beans.MathServiceImpl;

public class MainClass {

	public static void main(String[] args) {
		MathService mathservice = new MathServiceImpl();
		System.out.println(mathservice.add(100, 200));
		System.out.println(mathservice.sub(600, 200));

	}

}
