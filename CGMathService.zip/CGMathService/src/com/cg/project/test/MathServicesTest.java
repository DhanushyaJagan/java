package com.cg.project.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.exception.InvalidNoRangeException;
import com.cg.project.services.MathServiceImpl;
import com.cg.project.services.MathServices;

public class MathServicesTest {
private static MathServices services;
private int validnum1,validnum2,invalidnum1,invalidnum2,expectedAns;
@BeforeClass
public static void setUpTestEnv(){
	services=new MathServiceImpl();
}
@Before
public void setUpMockData(){
	validnum1=10;
	validnum2=20;
	invalidnum1=-12;
	invalidnum2=-23;
}
@Test(expected= InvalidNoRangeException.class)
public void TestAddForFirstInvalidNo()throws InvalidNoRangeException{
	services.add(invalidnum1, validnum2);
}
@Test(expected= InvalidNoRangeException.class)
public void TestAddForSecondInvalidNo()throws InvalidNoRangeException{
	services.add(validnum1, invalidnum2);
}
@Test
public void TestAddForvalidNo()throws InvalidNoRangeException{
	Assert.assertEquals(30, services.add(validnum1, validnum2));
}
@Test
public void TestSubForvalidNo()throws InvalidNoRangeException{
	Assert.assertEquals(-10, services.sub(validnum1, validnum2));
}
@Test(expected= InvalidNoRangeException.class)
public void TestSubForFirstInvalidNo()throws InvalidNoRangeException{
	services.sub(invalidnum1, validnum2);
}
@Test(expected= InvalidNoRangeException.class)
public void TestSubForSecondInvalidNo()throws InvalidNoRangeException{
	services.sub(validnum1, invalidnum2);
}
@Test
public void TestDivForvalidNo()throws InvalidNoRangeException{
	Assert.assertEquals(0, services.div(validnum1, validnum2));
}
@Test(expected= InvalidNoRangeException.class)
public void TestDivForFirstInvalidNo()throws InvalidNoRangeException{
	services.div(invalidnum1, validnum2);
}
@Test(expected= InvalidNoRangeException.class)
public void TestDivForSecondInvalidNo()throws InvalidNoRangeException{
	services.div(validnum1, invalidnum2);
}
@After
public void tearDownMockDta(){
	validnum1=10;
	validnum2=20;
	invalidnum1=-12;
	invalidnum2=-23;
	expectedAns=0;
}
@AfterClass
public static void setUp(){
	services=null;
	
}
}