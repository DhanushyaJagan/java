package com.cg.project.main;

public class MainClass {

	public static void main(String[] args) {

	}

}
