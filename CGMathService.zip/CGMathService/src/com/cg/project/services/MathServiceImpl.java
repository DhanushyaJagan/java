package com.cg.project.services;
import com.cg.project.exception.InvalidNoRangeException;
public class MathServiceImpl implements MathServices{

	@Override
	public int add(int n1, int n2) throws InvalidNoRangeException {
		if(n1<0||n2<0)throw new InvalidNoRangeException();
		else{
		int n3 = n1+n2;		
		return n3;
		}
	}

	@Override
	public int sub(int n1, int n2) throws InvalidNoRangeException {
		if(n1<0)throw new InvalidNoRangeException();
		if(n2<0)throw new InvalidNoRangeException();
		int n3=n1-n2;
		return n3;
	}

	@Override
	public int div(int n1, int n2) throws InvalidNoRangeException {
		if(n1<0)throw new InvalidNoRangeException();
		if(n2<0)throw new InvalidNoRangeException();
		int n3=n1/n2;
		return n3;
	}
	
}
