package com.cg.project.exception;

@SuppressWarnings("serial")
public class InvalidNoRangeException extends Exception{

	public InvalidNoRangeException() {
		super();
	}

	public InvalidNoRangeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public InvalidNoRangeException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidNoRangeException(String message) {
		super(message);
	}

	public InvalidNoRangeException(Throwable cause) {
		super(cause);
	}
	
}
