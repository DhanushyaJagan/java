package com.cg.payroll.aspectcontroller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.PayrollServicesDownException;

@ControllerAdvice(basePackages="com.cg.payroll.controllers")
public class PayrollAspectController {
@ExceptionHandler(value=PayrollServicesDownException.class)
public String payrollServicesDownException() {
	return "errorPage";
}

@ExceptionHandler(value=AssociateDetailsNotFoundException.class)
public ModelAndView associateDetailsNotFound() {
	ModelAndView modelAndView =new ModelAndView();
	modelAndView.setViewName("loginPage");
	modelAndView.addObject("associate", new Associate());
	return modelAndView;
}
}
