package com.cg.payroll.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

@Controller
public class LoginController {
	@Autowired
	PayrollServices payrollServices;
	@RequestMapping(value="/authUser")
	public String authUser(@ModelAttribute("associate")Associate associate) throws AssociateDetailsNotFoundException, PayrollServicesDownException{
		
			if(associate.getPassword().equals(payrollServices.getAssociateDetails(associate.getAssociateID()).getPassword())){
				return "loginSuccess";
			}
			throw new AssociateDetailsNotFoundException();
		
}
}
