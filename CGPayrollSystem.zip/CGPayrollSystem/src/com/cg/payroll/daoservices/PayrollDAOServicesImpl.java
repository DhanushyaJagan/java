package com.cg.payroll.daoservices;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.Associate;
public class PayrollDAOServicesImpl implements PayrollDAOService {
	HashMap<Integer,Associate> associates=new HashMap<Integer,Associate>();
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;
	@Override
	public int insertAssociate(Associate associate){
		associates.put(ASSOCIATE_ID_COUNTER,associate);
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		return associate.getAssociateID();
	}
	@Override
	public boolean updateAssociate(Associate associate){
		associates.put(associate.getAssociateID(),associate);
return true;
			}
	
	
	@Override
	public boolean deleteAssociate(int associateId){
	associates.remove(associateId);
	
	return true;
	}
	@Override                                                                                                                                                                                   
	public Associate getassociate(int associateId){
		 return associates.get(associateId);
		 
	}
	@Override
	public List<Associate> getAssociates(){
		 List<Associate> associatelist= new ArrayList<Associate>(associates.values());
	return associatelist;
	}
}

                                                                                