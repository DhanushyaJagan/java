package com.cg.payroll.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

import com.cg.payroll.beans.Associate;

public class PayrollSerialize {
	public static void doSerialization(File file) throws FileNotFoundException, IOException{
		HashMap<Integer,Associate> associates=new HashMap<Integer,Associate>();
		try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(file))){
			dest.writeObject(associates);
		}
	}
	public static void doDeSerialization(File file) throws FileNotFoundException, IOException, ClassNotFoundException{
		
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(file))){
			Associate associates=(Associate)src.readObject();
			//(Associate)src.close();
		}
	}
}
