package com.cg.payroll.daoservices;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.cg.payroll.beans.Associate;

public interface PayrollDAOService  {

	public abstract int insertAssociate(Associate associate);

	public abstract boolean updateAssociate(Associate associate);

	public abstract boolean deleteAssociate(int associateId);

	public abstract Associate getassociate(int associateId);

	public abstract List<Associate> getAssociates();
	public abstract  void doSerialization(File file) throws FileNotFoundException, IOException ;
		public abstract void doDeSerialization(File file)throws FileNotFoundException, IOException,ClassNotFoundException;
}