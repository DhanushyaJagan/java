package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;

public interface PayrollService {

	public abstract int acceptAssociateDetails(int yearlyInvestmentUnder80c,
			String firstName, String lastName, String department,
			String designation, String pancard, String emailid, float epf,
			float companypf, float basicsalary, int accountnumber,
			String bankname, String ifsccode);
	
	public abstract float calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException;

	public abstract Associate getAssociateDetails(int associateId)throws AssociateDetailsNotFoundException;

	public abstract List<Associate> getAllAssociatesDetails();

}