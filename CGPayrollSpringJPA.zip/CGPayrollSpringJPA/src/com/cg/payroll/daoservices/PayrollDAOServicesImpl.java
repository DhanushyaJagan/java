package com.cg.payroll.daoservices;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;
import javax.sql.DataSource;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.PayrollServicesDownException;
@Component("payrollDaoServices")
public class PayrollDAOServicesImpl implements PayrollDAOService {
	@Autowired(required=true)
	private  EntityManagerFactory entityManagerFactory ;
	@Override
	public int insertAssociate(Associate associate) {
EntityManager entityManager=entityManagerFactory.createEntityManager();
entityManager.getTransaction().begin();
entityManager.persist(associate);
entityManager.flush();
entityManager.getTransaction().commit();
entityManager.close();
return associate.getAssociateID();
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);

entityManager.flush();
		entityManager.getTransaction().commit();
				return true;
	}

	@Override
	public boolean deleteAssociate(int associateID) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		Associate associate=entityManager.find(Associate.class,associateID);
		if (associate!=null){
		entityManager.remove(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		}
		entityManager.close();
				return true;	
	}

	@Override
	public Associate getAssociate(int associateID) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();

		return entityManager.find(Associate.class, associateID);
	}

	@Override
	public List<Associate> getAssociates() {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
TypedQuery<Associate> query=entityManager.createQuery("Select a from Associate",Associate.class);

		return query.getResultList();
	}

	
}





















/*@Override
	public int insertAssociate(Associate associate) throws SQLException {

		String sql = "insert into Associate(yearlyInvestmentUnder80c,firstName,lastName,department,designation,pancard,emailId)value(?,?,?,?,?,?,?)";
			int associateId=jdbcTemplate.update(sql,new Object[]{associate.getYearlyInvestmentUnder80C(),associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId()});	 
		String sql1="insert into Salary(associateId,basicSalary,epf,companypf)value(?,?,?,?)";
		jdbcTemplate.update(sql1,new Object[]{associateId,associate.getSalary().getBasicSalary(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf()});
		String sql2="insert into bankdetails(associateId,accountNumber,bankName,ifscCode)value(?,?,?,?)";	
		jdbcTemplate.update(sql2,new Object[]{associateId,associate.getBankdetails().getAccountNumber(),associate.getBankdetails().getBankName(),associate.getBankdetails().getIfscCode()});
		return associateId;
	}

	@Override
	public boolean updateAssociate(Associate associate)
			throws PayrollServicesDownException, SQLException {
		String sql="update Associate set yearlyInvestmentUnder80c = ?,firstName=?,lastName=?,department=?,designation=?,pancard=?,emailId=? where associateID = ?";
		jdbcTemplate.update(sql,new Object[]{associate.getYearlyInvestmentUnder80C(),associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId()});
		String sql1="udate Salary set basicSalary=?,epf=?, companypf=? where associateID = ?";
		jdbcTemplate.update(sql1,new Object[]{associate.getSalary().getBasicSalary(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf()});
		String sql2="update  BankingDetails set accountNumber=?,bankName=?,ifscCode=? where associateID = ?";	
		jdbcTemplate.update(sql2,new Object[]{associate.getBankdetails().getAccountNumber(),associate.getBankdetails().getBankName(),associate.getBankdetails().getIfscCode()});
		return true;

	}

	@Override
	public boolean deleteAssociate(int associateID) {
		 String sql = "delete from associate where associateID = ?";
	    //    jdbcTemplate.update(sql,new Object[]{associateID});
	        Object[] associate = new Object[] {associateID};
	        jdbcTemplate.update(sql, associate);

		return true;
	}

	@Override
	public Associate getAssociate(int associateID)
			throws PayrollServicesDownException, SQLException {
		return null;
	}

	@Override
	public List<Associate> getAssociates() throws SQLException {

        Object[] associate = new Object[] {associateID};

		  int associateId = jdbcTemplate.queryForObject(

			        "SELECT * FROM associate WHERE asociateId=?", new Object[]{associate.getfirstName(), associate.getlastName()}, int.class);

		return null;
	}

}*/
/*private Connection con=null;
//public PayrollDAOServicesImpl() throws PayrollServicesDownException {
//	con=PayrollUtility.getDBConnection();
///}
	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		try{
			con.setAutoCommit(false);
			PreparedStatement pstmt1=con.prepareStatement("insert into associate( yearlyInvestmentUnder80C, firstName,  lastName,  department, designation,  pancard,  emailId)");
			pstmt1.setInt(1,associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2,associate.getFirstName());
			pstmt1.setString(3, associate.getLastName());
			pstmt1.setString(4, associate.getDepartment());
			pstmt1.setString(5, associate.getDesignation());
			pstmt1.setString(6, associate.getPancard());
			pstmt1.setString(7, associate.getEmailId());
			pstmt1.executeUpdate();
			PreparedStatement pstmt2=con.prepareStatement("select max(associateId)from associate");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			int associateId=rs.getInt(1);
			PreparedStatement pstmt3=con.prepareStatement("insert into Salary( basicSalary,  epf,  companyPf)");
			pstmt3.setInt(1, associateId);
			pstmt3.setFloat(2, associate.getSalary().getBasicSalary());
			pstmt3.setFloat(3, associate.getSalary().getEpf());
			pstmt3.setFloat(4, associate.getSalary().getCompanyPf());
			pstmt3.executeUpdate();
			PreparedStatement pstmt4=con.prepareStatement("insert into BankDetails( accountNumber,  bankName,  ifscCode)");
			pstmt4.setInt(1, associateId);
			pstmt4.setInt(2, associate.getBankdetails().getAccountNumber());
			pstmt4.setString(3, associate.getBankdetails().getBankName());
			pstmt4.setString(4, associate.getBankdetails().getIfscCode());
			pstmt4.executeUpdate();
			con.commit();
			return associateId;
			}catch(SQLException e){
				con.rollback();
				throw e;
			}finally{
				con.setAutoCommit(true);
			}
	}
	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		try{
			con.setAutoCommit(false);
			PreparedStatement pstmt1=con.prepareStatement("update into associate set yearlyInvestmentUnder80C=?,  firstName=?,  lastName=?,  department=?,designation=?,  pancard=?,  emailId=? where associateId=?");

			pstmt1.setInt(1,associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2, associate.getFirstName());
			pstmt1.setString(3, associate.getLastName());
			pstmt1.setString(4,associate.getDepartment());
			pstmt1.setString(5, associate.getDesignation());
			pstmt1.setString(6, associate.getPancard());
			pstmt1.setString(7, associate.getEmailId());
			pstmt1.executeUpdate();
			PreparedStatement pstmt2=con.prepareStatement("update into bankdetails set accountNumber=?,  bankName=?,  ifscCode=? where associateId=?");
			pstmt2.setInt(1,associate.getAssociateID());
			pstmt2.setInt(2, associate.getBankdetails().getAccountNumber());
			pstmt2.setString(3, associate.getBankdetails().getBankName());
			pstmt2.setString(4, associate.getBankdetails().getIfscCode());
			pstmt2.executeUpdate();
			PreparedStatement pstmt3=con.prepareStatement("update into Salary set basicSalary=?,  hra=?,  conveyenceAllowance=?,  otherAllowance=?,personalAllowance=?,  monthlyTax=?,  epf=?,  companyPf=?,  gratuity=?,  grossSalary=?, netSalary=? where associateid=?");	
			pstmt3.setFloat(1, associate.getSalary().getBasicSalary());
			pstmt3.setFloat(2, associate.getSalary().getHra());
			pstmt3.setFloat(3, associate.getSalary().getConveyenceAllowance());
			pstmt3.setFloat(4, associate.getSalary().getOtherAllowance());
			pstmt3.setFloat(5,associate.getSalary().getPersonalAllowance());
			pstmt3.setFloat(6, associate.getSalary().getMonthlyTax());
			pstmt3.setFloat(7, associate.getSalary().getEpf());
			pstmt3.setFloat(8, associate.getSalary().getCompanyPf());
			pstmt3.setFloat(9, associate.getSalary().getGratuity());
			pstmt3.setFloat(10, associate.getSalary().getGrossSalary());
			pstmt3.setFloat(11, associate.getSalary().getNetSalary());
			pstmt3.setInt(12, associate.getAssociateID());
			pstmt3.executeUpdate();
			con.commit();
			return true;
		}catch(SQLException e){
			con.rollback();
			throw e;
		}finally{
			con.setAutoCommit(true);
		}
	}
	@Override
	public boolean deleteAssociate(int associateID) {
				return false;
	}
	@Override
	public Associate getAssociate(int associateID) throws PayrollServicesDownException, SQLException {
		PreparedStatement pstmt1=con.prepareStatement("select a.associateId,a.yearlyInvestmentUnder80C,  a.firstName,  a.lastName,  a.department,a.designation,  a.pancard, a.emailId, b.accountNumber, b.bankName,b.ifscCode,s.basicSalary, s.hra, s.conveyenceAllowance, s.otherAllowance,s.personalAllowance,  s.monthlyTax,  s.epf,  s.companyPf,  s.gratuity,  s.grossSalary,s.netSalary"+
		"from Associate a inner join BankDetails b inner join Salary s"+
		"on  a.associateID=b.associateid and a.associateId=s.associateId"+
				"where a.associateID=?");
		pstmt1.setInt(1,associateID);
		ResultSet rs=pstmt1.executeQuery();
		if(rs.next()){
			return new Associate(associateID, rs.getInt("yearlyInvestmentUnder80C"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("department"), rs.getString("designation"), rs.getString("pancard"), rs.getString("emailId"),new Salary(rs.getInt("basicSalary"), rs.getInt("hra"), rs.getInt("conveyenceAllowance"), rs.getInt("otherAllowance"), rs.getInt("personalAllowance"), rs.getInt("monthlyTax"), rs.getInt("epf"), rs.getInt("companyPf"), rs.getInt("gratuity"), rs.getInt("grossSalary"), rs.getInt("netSalary")),new BankDetails(rs.getInt("accountNumber"), rs.getString("bankName"), rs.getString("ifscCode")));
		}

		return null;
	}
	@Override
	public List<Associate> getAssociates() throws SQLException {
		PreparedStatement pstmt1=con.prepareStatement("select a.associateId,a.yearlyInvestmentUnder80C,  a.firstName,  a.lastName,  a.department,a.designation,  a.pancard, a.emailId, b.accountNumber, b.bankName,b.ifscCode,s.basicSalary, s.hra, s.conveyenceAllowance, s.otherAllowance,s.personalAllowance,  s.monthlyTax,  s.epf,  s.companyPf,  s.gratuity,  s.grossSalary,s.netSalary"+
				"from Associate a inner join BankDetails b inner join Salary s"+
				"on  a.associateID=b.associateid and a.associateId=s.associateId"+
						"where a.associateID=?");
		ResultSet rs=pstmt1.executeQuery();


		return null;
	}
 */
