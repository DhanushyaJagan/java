package com.cg.payroll.daoservices;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.PayrollServicesDownException;

public interface PayrollDAOService {
	int insertAssociate(Associate associate);

	boolean updateAssociate(Associate associate) ;

	boolean deleteAssociate(int associateID);

	Associate getAssociate(int associateID);

	List<Associate> getAssociates() ;

}
