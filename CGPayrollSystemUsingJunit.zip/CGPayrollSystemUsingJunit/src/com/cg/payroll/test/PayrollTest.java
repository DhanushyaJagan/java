package com.cg.payroll.test;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.PayrollServiceDownException;
import com.cg.payroll.services.PayrollService;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollTest {
	private static PayrollService payrollservices;
	@BeforeClass
	public static void setUpTestEnv(){
		payrollservices=new PayrollServicesImpl();
	}
	@Before
	public void setUpMockData(){
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;
		Associate associate1=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER,2222, "DHANU", "JAGN", "JAVA", "SE", "HU66", "DHAN@KI.COM", new Salary(2500000, 200, 200), new BankDetails(265786890, "HDFC", "HFDC56"));
		PayrollDAOServicesImpl.associates.put(PayrollUtility.ASSOCIATE_ID_COUNTER++,associate1);
	}

	@Test
	public void testAcceptAssociateDetailsForValidData()throws AssociateDetailsNotFoundException{
		int expectedId=112;
		Associate associate2 =new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER,2222, "DHANU", "JAGAN", "JAVA", "SE", "HU66", "DHAN@KI.COM", new Salary(250000, 200, 200), new BankDetails(265786890, "HDFC", "HFDC56"));
		PayrollDAOServicesImpl.associates.put(PayrollUtility.ASSOCIATE_ID_COUNTER++,associate2);
		Assert.assertEquals(expectedId, associate2.getAssociateID());

	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidData()throws AssociateDetailsNotFoundException{
		Assert.assertEquals(111, payrollservices.getAssociateDetails(115));
	}
	
	@Test
	public void testGetAssociateDetailsForvalidData()throws AssociateDetailsNotFoundException,PayrollServiceDownException{
		Associate associate3=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER,2222, "DHANU", "JAGN", "JAVA", "SE", "HU66", "DHAN@KI.COM", new Salary(2500000, 200, 200), new BankDetails(265786890, "HDFC", "HFDC56"));
		PayrollDAOServicesImpl.associates.put(PayrollUtility.ASSOCIATE_ID_COUNTER++,associate3);
		Assert.assertEquals(associate3, payrollservices.getAssociateDetails(113));
	}

	@Test
	public void calculateNetSalaryForValidData()throws AssociateDetailsNotFoundException{
		int a=(int)payrollservices.calculateNetSalary(111);
		Assert.assertEquals(674213, a);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void calculateNetSalaryForInValidId()throws AssociateDetailsNotFoundException{
		int a=(int)payrollservices.calculateNetSalary(121);
		Assert.assertEquals(14400, a);
	}
	@After
	public void testDownMockData(){
		PayrollDAOServicesImpl.associates.clear();
	}
	@AfterClass
	public static void setup(){

	}
}
