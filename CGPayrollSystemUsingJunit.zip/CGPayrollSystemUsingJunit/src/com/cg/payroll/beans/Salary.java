package com.cg.payroll.beans;
public class Salary {
	private float basicsalary,annualsalary,hra,conveyenceallowance,	
	otherallowance,personalallowance,monthlytax,annualtax,
	epf,companypf,gratutity,grosssalary,netsalary;
	public Salary() {
	}

	public Salary(float basicsalary, float epf, float companypf) {
		super();
		this.basicsalary = basicsalary;
		this.epf = epf;
		this.companypf = companypf;
	}

	public Salary(float basicsalary, float annualsalary, float hra,
			float conveyenceallowance, float otherallowance,
			float personalallowance, float monthlytax, float annualtax,
			float epf, float companypf, float gratutity, float grosssalary,
			float netsalary) {
		super();
		this.basicsalary = basicsalary;
		this.annualsalary = annualsalary;
		this.hra = hra;
		this.conveyenceallowance = conveyenceallowance;
		this.otherallowance = otherallowance;
		this.personalallowance = personalallowance;
		this.monthlytax = monthlytax;
		this.annualtax = annualtax;
		this.epf = epf;
		this.companypf = companypf;
		this.gratutity = gratutity;
		this.grosssalary = grosssalary;
		this.netsalary = netsalary;
	}

	public float getBasicsalary() {
		return basicsalary;
	}

	public void setBasicsalary(float basicsalary) {
		this.basicsalary = basicsalary;
	}

	public float getAnnualsalary() {
		return annualsalary;
	}

	public void setAnnualsalary(float annualsalary) {
		this.annualsalary = annualsalary;
	}

	public float getHra() {
		return hra;
	}

	public void setHra(float hra) {
		this.hra = hra;
	}

	public float getConveyenceallowance() {
		return conveyenceallowance;
	}

	public void setConveyenceallowance(float conveyenceallowance) {
		this.conveyenceallowance = conveyenceallowance;
	}

	public float getOtherallowance() {
		return otherallowance;
	}

	public void setOtherallowance(float otherallowance) {
		this.otherallowance = otherallowance;
	}

	public float getPersonalallowance() {
		return personalallowance;
	}

	public void setPersonalallowance(float personalallowance) {
		this.personalallowance = personalallowance;
	}

	public float getMonthlytax() {
		return monthlytax;
	}

	public void setMonthlytax(float monthlytax) {
		this.monthlytax = monthlytax;
	}

	public float getAnnualtax() {
		return annualtax;
	}

	public void setAnnualtax(float annualtax) {
		this.annualtax = annualtax;
	}

	public float getEpf() {
		return epf;
	}

	public void setEpf(float epf) {
		this.epf = epf;
	}

	public float getCompanypf() {
		return companypf;
	}

	public void setCompanypf(float companypf) {
		this.companypf = companypf;
	}

	public float getGratutity() {
		return gratutity;
	}

	public void setGratutity(float gratutity) {
		this.gratutity = gratutity;
	}

	public float getGrosssalary() {
		return grosssalary;
	}

	public void setGrosssalary(float grosssalary) {
		this.grosssalary = grosssalary;
	}

	public float getNetsalary() {
		return netsalary;
	}

	public void setNetsalary(float netsalary) {
		this.netsalary = netsalary;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(annualsalary);
		result = prime * result + Float.floatToIntBits(annualtax);
		result = prime * result + Float.floatToIntBits(basicsalary);
		result = prime * result + Float.floatToIntBits(companypf);
		result = prime * result + Float.floatToIntBits(conveyenceallowance);
		result = prime * result + Float.floatToIntBits(epf);
		result = prime * result + Float.floatToIntBits(gratutity);
		result = prime * result + Float.floatToIntBits(grosssalary);
		result = prime * result + Float.floatToIntBits(hra);
		result = prime * result + Float.floatToIntBits(monthlytax);
		result = prime * result + Float.floatToIntBits(netsalary);
		result = prime * result + Float.floatToIntBits(otherallowance);
		result = prime * result + Float.floatToIntBits(personalallowance);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Salary other = (Salary) obj;
		if (Float.floatToIntBits(annualsalary) != Float
				.floatToIntBits(other.annualsalary))
			return false;
		if (Float.floatToIntBits(annualtax) != Float
				.floatToIntBits(other.annualtax))
			return false;
		if (Float.floatToIntBits(basicsalary) != Float
				.floatToIntBits(other.basicsalary))
			return false;
		if (Float.floatToIntBits(companypf) != Float
				.floatToIntBits(other.companypf))
			return false;
		if (Float.floatToIntBits(conveyenceallowance) != Float
				.floatToIntBits(other.conveyenceallowance))
			return false;
		if (Float.floatToIntBits(epf) != Float.floatToIntBits(other.epf))
			return false;
		if (Float.floatToIntBits(gratutity) != Float
				.floatToIntBits(other.gratutity))
			return false;
		if (Float.floatToIntBits(grosssalary) != Float
				.floatToIntBits(other.grosssalary))
			return false;
		if (Float.floatToIntBits(hra) != Float.floatToIntBits(other.hra))
			return false;
		if (Float.floatToIntBits(monthlytax) != Float
				.floatToIntBits(other.monthlytax))
			return false;
		if (Float.floatToIntBits(netsalary) != Float
				.floatToIntBits(other.netsalary))
			return false;
		if (Float.floatToIntBits(otherallowance) != Float
				.floatToIntBits(other.otherallowance))
			return false;
		if (Float.floatToIntBits(personalallowance) != Float
				.floatToIntBits(other.personalallowance))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Salary [basicsalary=" + basicsalary + ", annualsalary="
				+ annualsalary + ", hra=" + hra + ", conveyenceallowance="
				+ conveyenceallowance + ", otherallowance=" + otherallowance
				+ ", personalallowance=" + personalallowance + ", monthlytax="
				+ monthlytax + ", annualtax=" + annualtax + ", epf=" + epf
				+ ", companypf=" + companypf + ", gratutity=" + gratutity
				+ ", grosssalary=" + grosssalary + ", netsalary=" + netsalary
				+ "]";
	}



}
