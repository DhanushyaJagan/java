package com.cg.simplemavenproject

/**
 * Hello world!
 *
 */
object App extends Application {
  println( "Hello World!" )
}
