package com.cg.payroll.beans;

public class BankDetails {

	public BankDetails() {
		// TODO Auto-generated constructor stub
	}

}
