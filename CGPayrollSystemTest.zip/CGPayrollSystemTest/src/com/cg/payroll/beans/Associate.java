package com.cg.payroll.beans;

public class Associate {
	
	private int associateID,yearlyInvestmentunder80C;
	private String firstName,lastName,department,designation,pancard,emailId;
	private Salary salary;
	private BankDetails bankDetails;

	public Associate() {
		// TODO Auto-generated constructor stub
	}

	public Associate(int associateID, int yearlyInvestmentunder80C, String firstName, String lastName,
			String department, String designation, String pancard, String emailId, Salary salary,
			BankDetails bankDetails) {
		super();
		this.associateID = associateID;
		this.yearlyInvestmentunder80C = yearlyInvestmentunder80C;
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.designation = designation;
		this.pancard = pancard;
		this.emailId = emailId;
		this.salary = salary;
		this.bankDetails = bankDetails;
	}

	

}
