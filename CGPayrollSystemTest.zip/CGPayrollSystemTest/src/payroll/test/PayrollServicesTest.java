package payroll.test;
import static org.junit.Assert.*;

import org.junit.BeforeClass;
public class PayrollServicesTest {
	
	@BeforeClass
	public static void testGetPayroll(){
		
	}

}
