package com.cg.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreamDemo {
	public static void byteReadWriteWork(File fromFile,File toFile) throws IOException{
		try(BufferedInputStream src=new BufferedInputStream(new FileInputStream(fromFile))){
			try(BufferedOutputStream des=new BufferedOutputStream(new FileOutputStream(toFile))){
				int a=0;
				while((a=src.read())!=-1){
					des.write(a);
				}
				byte[] databuffer=new byte[(int) fromFile.length()];
				src.read(databuffer);
				des.write(databuffer);
			}	
			}
		
	}
		}
		//FileInputStream src=new FileInputStream(fromFile);
		//FileOutputStream des=new FileOutputStream(ToFile);
		

