package com.cg.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.cg.io.beans.Associate;

public class SerializationDemo {
public static void doSerialization(File file) throws FileNotFoundException, IOException{
	Associate associate=new Associate(1223, 98000, "dhanu", "moni");
	try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(file))){
	dest.writeObject(associate);
	}
}
public static void doDeSerialization(File file) throws ClassNotFoundException, IOException{
try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(file))){
Associate associate=(Associate)src.readObject();
}
}
}