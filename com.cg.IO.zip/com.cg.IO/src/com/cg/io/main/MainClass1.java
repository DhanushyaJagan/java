package com.cg.io.main;

import java.io.File;
import java.io.IOException;




import com.cg.io.ByteStreamDemo;
import com.cg.io.SerializationDemo;
public class MainClass1 {
	public static void main(String[] args) throws ClassNotFoundException {
		try {
			File file=new File("D:\\moni.txt");
			File fromFile=new File("D:\\moni.txt");
			File toFile=new File("D:\\dhanush.txt");

			if(!fromFile.exists())
				
			fromFile.createNewFile();
			if(!toFile.exists())
				
			toFile.createNewFile();
			SerializationDemo.doSerialization(fromFile);	
			SerializationDemo.doDeSerialization(toFile);
			ByteStreamDemo.byteReadWriteWork(fromFile, toFile);
			System.out.println(fromFile.length());
			System.out.println(fromFile.canRead());
			System.out.println(fromFile.canWrite());
			System.out.println(fromFile.getPath());
			System.out.println(fromFile.getName());
			System.out.println(fromFile.canExecute());
		}
		
		catch (IOException e) {
			e.printStackTrace();
		}

	}
}
