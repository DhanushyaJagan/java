package com.cg.abs.beans;

import com.cg.abs.beans.PEmployee;

//final for last child class it cannot be inherited/
	public final class Developer extends PEmployee{
		private int noOfProj,incentive;

		public Developer() {
			super();
		}

		//public Developer(int employeeId, int basicSalary, String firstName,	String secondName) {
		//	super(employeeId, basicSalary, firstName, secondName);

		//}

		public Developer(int employeeId, int basicSalary, String firstName,	String secondName,int noOfProj) {
			super(employeeId, basicSalary, firstName, secondName);
			this.noOfProj=noOfProj;
		}

		public int getNoOfProj() {
			return noOfProj;
		}

		public void setNoOfProj(int noOfProj) {
			this.noOfProj = noOfProj;
		}

		public int getIncentive() {
			return incentive;
		}

		public void setIncentive(int incentive) {
			this.incentive = incentive;
		}

		@Override
		public void setCalculatorTotalsalary() {
			super.setCalculatorTotalsalary();
			this.incentive=getNoOfProj()*5000;
		}

		@Override
		public String toString() {

			return super.toString()+" "+"NO OF PROJ="+getNoOfProj()+" "+"INCENTIVE"+incentive;
		}

}
