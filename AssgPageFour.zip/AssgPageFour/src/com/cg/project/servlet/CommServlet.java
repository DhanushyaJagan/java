package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.project.beans.BasicClass;
import com.sun.swing.internal.plaf.basic.resources.basic;

@WebServlet("/CommServlet")
public class CommServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public CommServlet() {
        super();
    }

	public void init( ) throws ServletException {

	}

	public void destroy() {
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		//BasicClass basicClass = new BasicClass(city, state);

		HttpSession session = request.getSession(false);
		if(session!=null) {
			BasicClass basicClass =(BasicClass)session.getAttribute("basicClass");
			basicClass.setCity(city);
			basicClass.setState(state);
			//userBean.setMovieName(movieName);
		//String firstName=(String) session.getAttribute("firstName");
		//String lastName=(String) session.getAttribute("lastName");
		//session.setAttribute("city", basicClass.getCity());
		//session.setAttribute("state", basicClass.getState());
	//	String firstName=(String)request.getParameter("firstName");
	//	String lastName=(String)request.getParameter("lastName");
	//	String city=(String)request.getParameter("city");
	//	String state=(String)request.getParameter("state");

		//BasicClass basicClass = new BasicClass(firstName, lastName);
	//	HttpSession session = request.getSession(false);
		//if(session!=null) {
		//	BasicClass basicClass =(BasicClass)session.getAttribute("basicClass");
		//	basicClass.setFirstName(firstName);
		//	basicClass.setLastName(lastName);
		//	basicClass.setCity(city);
		//	basicClass.setState(state);
			PrintWriter writer=response.getWriter();
			writer.println("<html>");
			writer.println("<body>");
			writer.println("<div align='center'>");
			writer.println("</br>");

			writer.println("<form action='ResultServlet' method= 'post'> ");

			//writer.println("<table>");
			//writer.println("<tr>");
			writer.println("<td>firstName:</td>"+basicClass.getFirstName());
			writer.println("</br>");
			//writer.println("</tr>");
			//writer.println("<tr>");
			writer.println("<td>lastName:</td>"+basicClass.getLastName());
			writer.println("</br>");
			//writer.println("</tr>");
			//writer.println("<tr>");
			
			writer.println("<td>city:</td>"+basicClass.getCity());
			writer.println("</br>");
			writer.println("<td>state:</td>"+basicClass.getState());
			writer.println("</br>");
			//writer.println("</tr>");
		//	writer.println("<tr>");
			writer.println("<td>email</td>");
			writer.println("<td><input type='text' name='email'></td>");
			writer.println("</br>");

			writer.println("<td>mobNo</td>");
			writer.println("<td><input type='text' name='mobNo'></td>");
			
			//writer.println("</tr>");
			//writer.println("<tr>");
			writer.println("<td><input type='submit' value='submit'></td>");
			//writer.println("</tr>");
			writer.println("</form>");
			//writer.println("</table>");
			writer.println("</div>");
			writer.println("</body>");
			writer.println("</head>");
			writer.println("</html>");
			}
		//else{
			
		//BasicClass basicClass=(BasicClass)context.getAttribute("basicClass");
		//basicClass.setCity(request.getParameter("city"));
	
		//basicClass.setState(request.getParameter("state"));
		//context.setAttribute("basicClass", basicClass);
		//	BasicClass basicClass =(BasicClass)session.getAttribute("basicClass");
		//	basicClass.setFirstName(firstName);
		//	basicClass.setLastName(lastName);
		//PrintWriter writer=response.getWriter();
		
		
		
		
		//String firstName=request.getParameter("firstName");
		//String lastName=request.getParameter("lastName");
		//String city=request.getParameter("city");
		////String state=request.getParameter("state");
	//	BasicClass basicClass = new BasicClass(firstName, lastName, city, state);
		//context.setAttribute("basicClass", basicClass);
		//PrintWriter writer=response.getWriter();
		//writer.println("<html>");
		///writer.println("<body>");
		//writer.println("<div align='center'>");
		//writer.println("</br>");

		//writer.println("<form action='ResultServlet' method= 'post'> ");

		//writer.println("<table>");
		//writer.println("<tr>");
	//	writer.println("<td>firstName:</td>"+basicClass.getFirstName());
	//	writer.println("</br>");
	//	//writer.println("</tr>");
		//writer.println("<tr>");
		//writer.println("<td>lastName:</td>"+basicClass.getLastName());
		//writer.println("</br>");
		//writer.println("</tr>");
		//writer.println("<tr>");
		
	//	writer.println("<td>city:</td>"+basicClass.getCity());
	//	writer.println("</br>");
	//	writer.println("<td>state:</td>"+basicClass.getState());
	//	writer.println("</br>");
		//writer.println("</tr>");
	//	writer.println("<tr>");
	//	writer.println("<td>email</td>");
	//	writer.println("<td><input type='text' name='email'></td>");
	//	writer.println("</br>");
//
	//	writer.println("<td>mobNo</td>");
		//writer.println("<td><input type='text' name='mobNo'></td>");
		
		//writer.println("</tr>");
		////writer.println("<tr>");
		//writer.println("<td><input type='submit' value='submit'></td>");
		//writer.println("</tr>");
		//writer.println("</form>");
		//writer.println("</table>");
		//writer.println("</div>");
		//writer.println("</body>");
		//writer.println("</head>");
	//	writer.println("</html>");
	//	}
	}

}
