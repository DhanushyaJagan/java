package com.cg.cgcoll.collections;

import java.util.ArrayList;
import java.util.List;

import com.cg.cgcoll.beans.Customer;

public class MainClass {

	public static void main(String[] args) {			
		
	ArrayList<Integer> inte =new ArrayList<Integer>();
	inte.add(10);
	inte.add(20);
	inte.add(20);

	for (Integer integer : inte) {
		System.out.println(inte);
	}
	ArrayList<String> strr =new ArrayList<String>();
	strr.add("nimmi");
	strr.add("jagan");
	strr.add("dhanu");
	strr.add("sowmi");
		for (String string : strr) {
		System.out.println(strr);

	}
		MyGeneric<String> str=new MyGeneric<String>("DHANU", "JAGAN");
		MyGeneric<Customer> customer=new MyGeneric<Customer>(new Customer(222, "DHANU", "MONI"),new Customer(333, "KAMALAM", "MONI") );
				System.out.println(customer);
				System.out.println(str);
				

	}

}
