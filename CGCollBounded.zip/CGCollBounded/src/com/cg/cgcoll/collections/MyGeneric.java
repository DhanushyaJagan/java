package com.cg.cgcoll.collections;

import java.util.List;

public class MyGeneric<T extends Comparable<T>>{
private T obj1,obj2;

public MyGeneric(T obj1, T obj2) {
	super();
	this.obj1 = obj1;
	this.obj2 = obj2;
}

public T getObj1() {
	return obj1;
}

@Override
public String toString() {
	return "MyGeneric [obj1=" + obj1 + ", obj2=" + obj2 + "]";
}

public void setObj1(T obj1) {
	this.obj1 = obj1;
}

public T getObj2() {
	return obj2;
}

public void setObj2(T obj2) {
	this.obj2 = obj2;
}

}
