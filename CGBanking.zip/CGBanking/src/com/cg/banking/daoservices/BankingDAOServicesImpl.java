package com.cg.banking.daoservices;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.beans.Account;
import com.cg.banking.utlility.BankingUtility;
public class BankingDAOServicesImpl implements BankingDAOServices{
	HashMap<Integer,Customer> customers=new HashMap<Integer,Customer>();
	
	@Override
	public int insertCustomer(Customer customer) {
		customers.put(BankingUtility.CUSTOMER_ID, customer);
		customer.setCustomerId(BankingUtility.CUSTOMER_ID++);
		return customer.getCustomerId();
	}
	@Override
	public long insertAccount(int customerId, Account account) {
		customers.get(customerId).getAccounts().put(BankingUtility.ACCOUNT_NO, account);
		account.setAccountNo(BankingUtility.ACCOUNT_NO++);
		return account.getAccountNo();		
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		customers.get(customerId).getAccounts().put(account.getAccountNo(), account);
		return true;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		 account.setPinNumber(BankingUtility.PIN++);
		return account.getPinNumber();
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo,
			Transaction transaction) {
		customers.get(customerId).getAccounts().get(accountNo).getTransactions().put(BankingUtility.TRANSACTION_ID, transaction);
		transaction.setTransactionId(BankingUtility.TRANSACTION_ID++);
		return true;
	}	
	@Override
	public boolean deleteCustomer(int customerId) {
		customers.remove(customerId);
		return true;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		customers.get(customerId).getAccounts().remove(accountNo);
		return true;
	}
	@Override
	public Customer getCustomer(int customerId) {
		return customers.get(customerId);
	}
	@Override
	public Account getAccount(int customerId, long accountNo) {
		return customers.get(customerId).getAccounts().get(accountNo);
	}
	@Override
	public Transaction getTransaction(int customerId, long accountNo,
			int transactionId) {
		return customers.get(customerId).getAccounts().get(accountNo).getTransactions().get(transactionId);
	}
	@Override
	public List<Customer> getCustomers() {
		List<Customer> customerlist=new ArrayList<Customer>(customers.values());
		return 	customerlist;
	}
	@Override
	public List<Account> getAccounts(int customerId) {
		List<Account> accountlist=new ArrayList<Account>(customers.get(customerId).getAccounts().values());
		return accountlist;
	}
	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		List<Transaction> transactionlist=new ArrayList<Transaction>(customers.get(customerId).getAccounts().get(accountNo).getTransactions().values());
		return transactionlist;
	}
	
}