package com.cg.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Academicasaervlet")
public class Academicasaervlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Academicasaervlet() {
        super();
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init(ServletConfig config)");
	}

	
	public void destroy() {
		System.out.println("destroy() ");
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("service()");
		PrintWriter writer=response.getWriter();
		String university_school=request.getParameter("university/school");
		String course=request.getParameter("course");
		String starting_year=request.getParameter("starting_year");
		String ending_year=request.getParameter("ending_year");
		String percentage=request.getParameter("percentage");
		String passing_year=request.getParameter("passing_year");
		String board=request.getParameter("board");
		String country=request.getParameter("country");
		String state=request.getParameter("state");
		String city=request.getParameter("city");
		writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("<font color='red' size=15>");
		writer.println(" university_school:"+university_school);
		writer.println("<br/>");
		writer.println("course:"+course);
		writer.println("<br/>");
		writer.println("starting_year:"+starting_year);
		writer.println("<br/>");
		writer.println("ending_year:"+ending_year);
		writer.println("<br/>");
		writer.println("percentage"+percentage);
		writer.println("<br/>");
		writer.println("passing_year:"+passing_year);
		writer.println("<br/>");
		writer.println("board:"+board);
		writer.println("<br/>");
		writer.println("country:"+country);
		writer.println("<br/>");
		writer.println("state:"+state);
		writer.println("<br/>");
		writer.println("city:"+city);
		writer.println("<br/>");
			
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");

		
	}



}
