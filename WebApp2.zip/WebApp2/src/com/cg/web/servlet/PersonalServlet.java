package com.cg.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/PersonalServlet")
public class PersonalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public PersonalServlet() {
        super();
    }


	public void init(ServletConfig config) throws ServletException {
        System.out.println("init(ServletConfig config)");
}

	
	public void destroy() {
		System.out.println("destroy()");
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("service()");
		PrintWriter writer=response.getWriter();
		String FirstName=request.getParameter("FirstName");
		String LastName=request.getParameter("LastName");
		String FatherName=request.getParameter("FatherName");
		String MotherName=request.getParameter("MotherName");
		String DOB=request.getParameter("DOB");
		String gender=request.getParameter("gender");
		String MobileNumber=request.getParameter("MobileNumber");
		String Email=request.getParameter("Email");
		String AlternateEmail=request.getParameter("AlternateEmail");
		String [] communication=request.getParameterValues("communication");
		String Address=request.getParameter("Address");
		String LanguagesKnoun=request.getParameter("LanguagesKnoun");
		String Enter_about_u=request.getParameter("Enter_about_u");
		String Upload_photo=request.getParameter("filename");
		System.out.println(FirstName);
		System.out.println(LastName);
		System.out.println(FatherName);
		System.out.println(MotherName);
		System.out.println(DOB);
		System.out.println(gender);
		System.out.println(MobileNumber);
		System.out.println(Email);
		System.out.println(AlternateEmail);
		System.out.println(communication);
		System.out.println(Address);
		System.out.println(LanguagesKnoun);
		System.out.println(Enter_about_u);
		System.out.println(Upload_photo);
		writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("<font color='red' size=15>");
		writer.println(" FirstName:"+FirstName);
		writer.println("<br/>");
		writer.println("LastName:"+LastName);
		writer.println("<br/>");
		writer.println("FatherName:"+FatherName);
		writer.println("<br/>");
		writer.println("MotherName:"+MotherName);
		writer.println("<br/>");
		writer.println("DOB:"+DOB);
		writer.println("<br/>");
		writer.println("gender:"+gender);
		writer.println("<br/>");
		writer.println("MobileNumber:"+MobileNumber);
		writer.println("<br/>");
		writer.println("Email:"+Email);
		writer.println("<br/>");
		writer.println("AlternateEmail:"+AlternateEmail);
	
		writer.println("<br>communication<ul> ");
	    for (int i=0;i<communication.length; i++) {
	    	writer.println(  communication[i]);
	  }
	    writer.println("</ul>");
		writer.println("<br/>");
		writer.println("Address:"+Address);
		writer.println("<br/>");
		writer.println("LanguagesKnoun:"+LanguagesKnoun);
		writer.println("<br/>");
		writer.println("Enter_about_u:"+Enter_about_u);
		writer.println("<br/>");
		
		writer.println("file:"+Upload_photo);	
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");

		
	}

}
