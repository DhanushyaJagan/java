package com.cg.project.services;

public class GreetingServicesImpl implements GreetingServices {

	@Override
	public void sayHello(String personNmae) {
System.out.println("Hello"+ personNmae);
System.out.println("GoodBye"+ personNmae);		

	}

	@Override
	public void GoodBye(String personNmae) {
		System.out.println("GoodBye"+ personNmae);		
		
	}

}
