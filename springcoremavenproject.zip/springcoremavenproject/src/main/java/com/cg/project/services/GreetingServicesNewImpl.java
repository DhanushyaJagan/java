package com.cg.project.services;

import org.springframework.stereotype.Component;
@Component("greetingServices")

public class GreetingServicesNewImpl implements GreetingServices {

	@Override
	public void sayHello(String personNmae) {
		System.out.println("Hello"+ personNmae);
	}

	@Override
	public void GoodBye(String personNmae) {
		System.out.println("GoodBye"+ personNmae);		

	}

}
