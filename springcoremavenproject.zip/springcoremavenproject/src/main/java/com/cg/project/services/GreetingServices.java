package com.cg.project.services;

public interface GreetingServices {

	void sayHello(String string);
	void GoodBye(String string);


}
