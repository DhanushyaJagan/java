package com.cg.dynamic.main;

import com.cg.dynamic.beans.CEmployee;
import com.cg.dynamic.beans.Employee;
import com.cg.dynamic.beans.SalesManager;

public class MainClass {

	public static void main(String[] args) {
		//Employee employee = new CEmployee(222, "DHANU", "MONI", 7);
		//employee.setCalculatorTotalsalary();
		//System.out.println(employee.toString());
		//CEmployee cemp =(CEmployee) employee;
		//cemp.signcontract();	
		//System.out.println(employee.toString());
		Employee employee = new SalesManager(333, 7888, "DHANU", "JAGAN", 299);
		employee.setCalculatorTotalsalary();
		SalesManager smng =(SalesManager) employee;
		smng.salesdone();
		System.out.println(employee.toString());
		
	}

}
