package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.BasicClass;

@WebServlet("/CommServlet")
public class CommServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public CommServlet() {
        super();
    }

	public void init(ServletConfig config) throws ServletException {
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		PrintWriter writer=response.getWriter();
		writer.println("<html>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("</br>");
		BasicClass basicClass = new BasicClass(firstName, lastName, city, state);

		writer.println("<form action='ResultServlet' method= 'post'> ");

		//writer.println("<table>");
		//writer.println("<tr>");
		writer.println("<td><input type=hidden name=firstName: value='"+basicClass.getFirstName()+"'></td>");

		//writer.println("<td><input type='hidden' > firstName:</td>"+basicClass.getFirstName());

		//writer.println("<td>firstName:</td>"+firstName);
		writer.println("</br>");
		//writer.println("</tr>");
		//writer.println("<tr>");
		writer.println("<td>lastName:</td>"+lastName);
		writer.println("</br>");
		//writer.println("</tr>");
		//writer.println("<tr>");
		
		writer.println("<td>city:</td>"+city);
		writer.println("</br>");
		writer.println("<td>state:</td>"+state);
		writer.println("</br>");
		//writer.println("</tr>");
	//	writer.println("<tr>");
		writer.println("<td>email</td>");
		writer.println("<td><input type='text' name='email'></td>");
		writer.println("</br>");

		writer.println("<td>mobNo</td>");
		writer.println("<td><input type='text' name='mobNo'></td>");
		
		//writer.println("</tr>");
		//writer.println("<tr>");
		writer.println("<td><input type='submit' value='submit'></td>");
		//writer.println("</tr>");
		writer.println("</form>");
		//writer.println("</table>");
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");
		}
	}


