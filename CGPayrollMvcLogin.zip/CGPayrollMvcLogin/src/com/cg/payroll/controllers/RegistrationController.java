package com.cg.payroll.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

@Controller
public class RegistrationController {
	@Autowired
	PayrollServices payrollservices;
	/*@RequestMapping(value="/registerUser")
	public String registerUser(@ModelAttribute("associate")Associate associate) {
		try{
			payrollservices.acceptAssociateDetails(associate);
			return "successPage";
		}catch(PayrollServicesDownException e){
			return "errorPage";
		}
	}*/

	@RequestMapping(value="/authUser")
	public String registerUser(@ModelAttribute("associate")Associate associate) {
	
		try{
			payrollservices.acceptAssociateDetails(associate);
			return "registrationSuccessPage";
		}catch(PayrollServicesDownException e){
			return "errorPage";
		}
		
	}

}
