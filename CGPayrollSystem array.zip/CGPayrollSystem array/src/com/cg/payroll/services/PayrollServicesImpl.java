package com.cg.payroll.services;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOService;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
public class PayrollServicesImpl implements PayrollService {

	private PayrollDAOService daoservices;
	private float taxamount;
	private float amnt;

	public PayrollServicesImpl(){
		daoservices=new PayrollDAOServicesImpl();
	}

	@Override
	public int acceptAssociateDetails(int yearlyInvestmentUnder80c,
			String firstName, String lastName, String department,
			String designation, String pancard, String emailid,
			float epf, float companypf, float basicsalary,
			int accountnumber, String bankname, String ifsccode	){

		return daoservices.insertAssociate(new Associate
				(yearlyInvestmentUnder80c, firstName, lastName, department, designation, pancard, emailid,new Salary(basicsalary, epf, companypf),new BankDetails(accountnumber, bankname, ifsccode)));

	}

	@Override
	public float calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException{
		Associate associate= this.getAssociateDetails(associateId);
		if(associate!=null){
			associate.getSalary().setPersonalallowance(((float)0.3)*associate.getSalary().getBasicsalary());
			associate.getSalary().setOtherallowance(((float)0.2)*associate.getSalary().getBasicsalary());
			associate.getSalary().setConveyenceallowance(((float)0.1)*associate.getSalary().getBasicsalary());
			associate.getSalary().setHra(((float)0.25)*associate.getSalary().getBasicsalary());
			associate.getSalary().setOtherallowance(((float)0.5)*associate.getSalary().getBasicsalary());
			associate.getSalary().setGrosssalary(associate.getSalary().getBasicsalary()+associate.getSalary().getCompanypf()+associate.getSalary().getHra()+associate.getSalary().getPersonalallowance()+associate.getSalary().getConveyenceallowance()+associate.getSalary().getOtherallowance());
			associate.getSalary().setAnnualsalary(associate.getSalary().getGrosssalary()*12);

			if(associate.getSalary().getBasicsalary()>0&&associate.getSalary().getBasicsalary()<=250000){
				taxamount=0;
				associate.getSalary().setAnnualtax(taxamount);
				associate.getSalary().setMonthlytax(associate.getSalary().getAnnualtax()/12 );
				return  associate.getSalary().getAnnualtax();
				
			}
			if(associate.getSalary().getBasicsalary()>250000&&associate.getSalary().getBasicsalary()<=500000){				
				amnt=(associate.getSalary().getBasicsalary()-250000-(associate.getYearlyInvestmentUnder80c()+associate.getSalary().getEpf()+associate.getSalary().getCompanypf()));
				taxamount=(float)0.1*amnt;
				associate.getSalary().setAnnualtax(taxamount);
				associate.getSalary().setMonthlytax(associate.getSalary().getAnnualtax()/12 );
				return  associate.getSalary().getAnnualtax();

			}

			if(associate.getSalary().getBasicsalary()>500000&&associate.getSalary().getBasicsalary()<=1000000){
				amnt=(associate.getSalary().getBasicsalary()-250000-(associate.getYearlyInvestmentUnder80c()+associate.getSalary().getEpf()+associate.getSalary().getCompanypf()));
				taxamount=(float)0.2*amnt;
				associate.getSalary().setAnnualtax(taxamount);
				associate.getSalary().setMonthlytax(associate.getSalary().getAnnualtax()/12 );
				return  associate.getSalary().getAnnualtax();

			}

			if(associate.getSalary().getBasicsalary()>1000000){
				amnt=(associate.getSalary().getBasicsalary()-250000-(associate.getYearlyInvestmentUnder80c()+associate.getSalary().getEpf()+associate.getSalary().getCompanypf()));
				taxamount=(float)0.3*amnt;
				associate.getSalary().setAnnualtax(taxamount);
				associate.getSalary().setMonthlytax(associate.getSalary().getAnnualtax()/12 );
				return  associate.getSalary().getAnnualtax();
			}

		}	
		return 0;
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException{
		Associate associate=daoservices.getassociate(associateId);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("associate details of ASSOCIATEID"+associateId+"not found");
		return daoservices.getassociate(associateId);
	}

	@Override
	
	
	
		public Associate[] getAllAssociatesDetails(){
		return daoservices.getAssociates();
	}
}
