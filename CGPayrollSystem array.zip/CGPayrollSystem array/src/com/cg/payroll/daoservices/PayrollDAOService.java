package com.cg.payroll.daoservices;

import com.cg.payroll.beans.Associate;

public interface PayrollDAOService  {

	public abstract int insertAssociate(Associate associate);

	public abstract boolean updateAssociate(Associate associate);

	public abstract boolean deleteAssociate(int associateId);

	public abstract Associate getassociate(int associateId);

	public abstract Associate[] getAssociates();

}