package com.cg.banking.main;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass1 {
	public static void main(String[] args) throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException{

		BankingServices bankingServices= new BankingServicesImpl();
		try {
			int CustomerId = bankingServices.acceptCustomerDetails("dhanu", "jagan", "dhan@gmail.com", "jiu89", "erode", "tn", 638005, "coimbatore", "tn", 638050);
			System.out.println(CustomerId);
			int CustomerId1 = bankingServices.acceptCustomerDetails("SOWMI", "jagan", "dhan@gmail.com", "jiu89", "erode", "tn", 638005, "coimbatore", "tn", 638050);
			long accno=bankingServices.openAccount(CustomerId, "savings", 77);
			System.out.println(accno);
			long accno1=bankingServices.openAccount(CustomerId1, "savings", 677);
			int PIN= bankingServices.generateNewPin(CustomerId,accno ); 
			int PIN1= bankingServices.generateNewPin(CustomerId1,accno1 ); 
			System.out.println("pin:"+PIN);
			System.out.println("balance after withdraw:"+bankingServices.withdrawAmount(CustomerId, accno, 40, PIN));
			System.out.println("balance after deposit:"+bankingServices.depositAmount(CustomerId, accno, 700));
			System.out.println("customer:"+bankingServices.getCustomerDetails(CustomerId));
			System.out.println("account:"+bankingServices.getAccountDetails(CustomerId, accno));
			System.out.println("transaction:"+bankingServices.getAccountAllTransaction(CustomerId, accno));
			System.out.println(CustomerId1);
			System.out.println(accno1);
			System.out.println("pin:"+PIN1);
			System.out.println("balance after withdraw:"+bankingServices.withdrawAmount(CustomerId1, accno1, 400, PIN1));
			System.out.println("balance after deposit:"+bankingServices.depositAmount(CustomerId1, accno1, 7000));
			System.out.println("fund transfer:"+bankingServices.fundTransfer(CustomerId, accno, CustomerId1, accno1, 500, PIN));
			System.out.println("customer:"+bankingServices.getCustomerDetails(CustomerId1));
			System.out.println("account:"+bankingServices.getAccountDetails(CustomerId1, accno1));
			System.out.println("transaction:"+bankingServices.getAccountAllTransaction(CustomerId1, accno1));
			System.out.println("pin change:"+bankingServices.changeAccountPin(CustomerId1, accno1, PIN1, 456));
			System.out.println(bankingServices.getAllCustomerDetails());
			System.out.println(bankingServices.getAccountAllTransaction(CustomerId1, accno1));
			System.out.println(bankingServices.getAccountDetails(CustomerId1, accno1));
			System.out.println(bankingServices.closeAccount(CustomerId, accno));

		} 	
		catch (BankingServicesDownException e) {
			e.printStackTrace();
		}
		catch (AccountNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (InsufficientAmountException e) {
			e.printStackTrace();
		} catch (InvalidPinNumberException e) {
			e.printStackTrace();
		} catch (AccountBlockedException e) {
			e.printStackTrace();
		}
	}
}





//Customer customer1=new Customer(4566, 145236789, "dhanu", "jagan", "6789uy", "3-09-1998", "dhanusow@gmail.com");
//Customer customer2=new Customer(4855, 125634789, "soemi", "jagan", "456ty", "9-07-1998", "sow@gmail.com");
//Customer customer3=new Customer(4562, 256789431, "nimmi", "jagan", "789ju", "09-03-1998", "nimmi@gmail.com");
//Account account1=new Account(5896745, 5869, "svings");
//Account account2=new Account(4534659, 586, "current");
//Account account3=new Account(5896655, 5268, "savings");
//Address address1=new Address("ERODE", "TN", "INDIA", 456987);
//Address address2=new Address("pune", "maharastra", "india", 458963);
//Address address3=new Address("salem", "tn", "india", 412589);
//Transaction transaction1=new Transaction(456245, 1256, "WITHDRAW");
//Transaction transaction2=new Transaction(423697, 123, "DEPOSIT");
//Transaction transaction3=new Transaction(452369, 2222, "WITHDRAW");
//System.out.println("CUSTOMER "+customer1.getCustomerID()+" "+customer1.getMobileNo()+" "+customer1.getDateOfBirth()+" "+customer1.getEmailID()+" "+customer1.getFirstName()+" "+customer1.getLastName()+" "+customer1.getPancardNo());
//System.out.println("ADDRESS "+address1.getCity()+" "+address1.getCountry()+" "+address1.getPincode()+" "+address1.getState());
//System.out.println("TRANSACTION "+transaction1.getTransactionAmount()+" "+transaction1.getTransactionID()+" "+transaction1.getTransactionType());
//System.out.println("ACCOUNT "+account1.getAccountBalance()+" "+account1.getAccountNo()+" "+account1.getAccountType());



