package com.cg.banking.utlility;

public class BankingUtility {
	public  static int CUSTOMER_ID=111;
	public  static long ACCOUNT_NO=111111;
	public static int PIN=123;
	public  static int TRANSACTION_ID=1234;
}
