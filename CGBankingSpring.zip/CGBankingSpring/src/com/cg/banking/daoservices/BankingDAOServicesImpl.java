package com.cg.banking.daoservices;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Transaction;




import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Account;
import com.cg.banking.utlility.BankingUtility;
public class BankingDAOServicesImpl implements BankingDAOServices{
	@Autowired
	private  SessionFactory sessionFactory ;
	Map<Integer,Customer> customers;

	@Override
	public int insertCustomer(Customer customer) {
		
			Session session= sessionFactory.openSession();
			Transaction tx=null;
			Integer customerId=null;
			try{
				tx=session.beginTransaction();
			 customerId=(Integer) session.save(customer);
			tx.commit();
		}
		catch(HibernateException e){
			if(tx!=null)
				tx.rollback();
			
		}
		finally{
		
			session.close();
		}
		return 0;		
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		Session session= sessionFactory.openSession();
	
	
	return 0;		
}
	
	@Override
	public boolean updateAccount(int customerId, Account account) {
		return false;
	
		
	}

	@Override
	public int generatePin(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo,
			com.cg.banking.beans.Transaction transaction) {
		return false;
	}

	
		

	@Override
	public boolean deleteCustomer(int customerId) {
		return false;
		
	
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		return false;
	
	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public com.cg.banking.beans.Transaction getTransaction(int customerId, long accountNo,
			int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<com.cg.banking.beans.Transaction> getTransactions(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	/*@Override
	public int insertCustomer(Customer customer) {
		customers.put(BankingUtility.CUSTOMER_ID, customer);
		customer.setCustomerId(BankingUtility.CUSTOMER_ID++);
		return customer.getCustomerId();
	}
	@Override
	public long insertAccount(int customerId, Account account) {
		customers.get(customerId).getAccounts().put(BankingUtility.ACCOUNT_NO, account);
		account.setAccountNo(BankingUtility.ACCOUNT_NO++);
		return account.getAccountNo();		
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		customers.get(customerId).getAccounts().put(account.getAccountNo(), account);
		return true;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		 account.setPinNumber(BankingUtility.PIN++);
		return account.getPinNumber();
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo,
			Transaction transaction) {
		customers.get(customerId).getAccounts().get(accountNo).getTransactions().put(BankingUtility.TRANSACTION_ID, transaction);
		transaction.setTransactionId(BankingUtility.TRANSACTION_ID++);
		return true;
	}	
	@Override
	public boolean deleteCustomer(int customerId) {
		customers.remove(customerId);
		return true;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		customers.get(customerId).getAccounts().remove(accountNo);
		return true;
	}
	@Override
	public Customer getCustomer(int customerId) {
		return customers.get(customerId);
	}
	@Override
	public Account getAccount(int customerId, long accountNo) {
		return customers.get(customerId).getAccounts().get(accountNo);
	}
	@Override
	public Transaction getTransaction(int customerId, long accountNo,
			int transactionId) {
		return customers.get(customerId).getAccounts().get(accountNo).getTransactions().get(transactionId);
	}
	@Override
	public List<Customer> getCustomers() {
		List<Customer> customerlist=new ArrayList<Customer>(customers.values());
		return 	customerlist;
	}
	@Override
	public List<Account> getAccounts(int customerId) {
		List<Account> accountlist=new ArrayList<Account>(customers.get(customerId).getAccounts().values());
		return accountlist;
	}
	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		List<Transaction> transactionlist=new ArrayList<Transaction>(customers.get(customerId).getAccounts().get(accountNo).getTransactions().values());
		return transactionlist;
	}*/
	
}