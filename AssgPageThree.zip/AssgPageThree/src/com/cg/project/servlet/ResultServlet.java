package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.BasicClass;

@WebServlet("/ResultServlet")
public class ResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ResultServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void init() {

	}

	
	public void destroy() {
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//BasicClass basicClass=(BasicClass)request.getAttribute("basicClass");
		//basicClass.setMobNo(request.getParameter("mobNo"));
		//basicClass.setEmail(request.getParameter("email"));
		//PrintWriter writer=response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String email=request.getParameter("email");
		String mobNo=request.getParameter("mobNo");

		BasicClass basicClass = new BasicClass(firstName, lastName, city, state, email, mobNo);
		request.setAttribute("basicClass", basicClass);
	//
		//String firstName=request.getParameter("firstName");
		//String lastName=request.getParameter("lastName");
		//String city=request.getParameter("city");
		//String state=request.getParameter("state");
		//String email=request.getParameter("email");
		//String mobNo=request.getParameter("mobNo");
		PrintWriter writer=response.getWriter();
		writer.println("<html>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("</br>");
		writer.println("<form> ");
		writer.println("<td>firstName:</td>"+basicClass.getFirstName());
		writer.println("</br>");
		writer.println("<td>lastName:</td>"+basicClass.getLastName());
		writer.println("</br>");
		writer.println("<td>city:</td>"+basicClass.getCity());
		writer.println("</br>");
		writer.println("<td>state:</td>"+basicClass.getState());
		writer.println("</br>");
		writer.println("<td>email:</td>"+basicClass.getEmail());
		writer.println("</br>");
		writer.println("<td>mobNo:</td>"+basicClass.getMobNo());
		writer.println("</form>");
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");
		}
	
	}


