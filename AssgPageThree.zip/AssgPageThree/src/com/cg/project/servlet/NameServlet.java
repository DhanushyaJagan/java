package com.cg.project.servlet;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.Out;

import com.cg.project.beans.BasicClass;

@WebServlet("/NameServlet")
public class NameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public NameServlet() {
        super();
    }
	public void init(ServletConfig config) throws ServletException {
	}
	public void destroy() {
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//String firstName=request.getParameter("firstName");
	//String lastName=request.getParameter("lastNmae");
	PrintWriter writer=response.getWriter();
	writer.println("<html>");
	writer.println("<body>");
	writer.println("<div align='center'>");
	writer.println("<form action='PlaceServlet' method='post'>");
	writer.println("<table>");
	writer.println("<tr>");
	writer.println("<td>First Name</td>");
	writer.println("<td><input type='text' name='firstName'></td>");
	writer.println("</tr>");
	writer.println("<tr>");
	writer.println("<td>Last Name</td>");
	writer.println("<td><input type='text' name='lastName'></td>");
	writer.println("</tr>");
	writer.println("<tr>");
	writer.println("<td><input type='submit' value='submit'></td>");
	writer.println("</tr>");
	writer.println("</table>");
	writer.println("</form>");
	writer.println("</div>");
	writer.println("</body>");
	writer.println("</head>");
	writer.println("</html>");
	}
	
}