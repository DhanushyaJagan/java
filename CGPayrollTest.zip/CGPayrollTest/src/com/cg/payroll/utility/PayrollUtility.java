package com.cg.payroll.utility;

public class PayrollUtility {
public static int ASSOCIATE_ID_COUNTER=111;
}
