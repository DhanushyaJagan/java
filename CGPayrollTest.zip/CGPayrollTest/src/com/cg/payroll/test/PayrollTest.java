package com.cg.payroll.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class PayrollTest {
private static PayrollService services;
	

}
