package com.cg.payroll.daoservices;
import com.cg.payroll.beans.Associate;
public class PayrollDAOServicesImpl implements PayrollDAOService {
	private static Associate[] associatelist = new Associate[2];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;
	@Override
	public int insertAssociate(Associate associate){
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associatelist[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID();
	}
	@Override
	public boolean updateAssociate(Associate associate){
		for(int i=0;i<associatelist.length;i++)
			if(associatelist[i]!=null&&associate.getAssociateID()==associatelist[i].getAssociateID()){
				associatelist[i]=associate;	
				return true;
			}
		return false;
	}
	@Override
	public boolean deleteAssociate(int associateId){
		for(int i=0;i<associatelist.length;i++)
			if(associatelist[i]!=null&&associateId==associatelist[i].getAssociateID()){
				associatelist[i]=null;
				if(associatelist[i+1]!=null);
				{
					associatelist[i]=associatelist[i+1];
					associatelist[i+1]=null;
				}
				return true;
			}
		return false;
	}
	@Override                                                                                                                                                                                   
	public Associate getassociate(int associateId){
		for(int i=0;i<associatelist.length;i++)
			if(associatelist[i]!=null&&associateId==associatelist[i].getAssociateID())
				return associatelist[i];
		return null;
	}
	@Override
	public Associate[] getAssociates(){
		return  associatelist;
	}
}

