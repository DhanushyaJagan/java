package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegistrationPage {
	@FindBy(id="user_login")
	WebElement UserName;
	@FindBy(id="user_email")
	WebElement Email;
	@FindBy(id="user_password")
	WebElement password;
	@FindBy(className="btn")
	WebElement button;
	public RegistrationPage() {
		super();
	}
	public void setUserName(String username){
		this.UserName.sendKeys(username);
	}
	public WebElement getPassword(){
		return password;
	}
	public void setPassword(String password){
		this.password.sendKeys(password);
	}
	public WebElement getEmail(){
		return Email;
	}
	public void setEmail(String email){
		this.Email.sendKeys(email);
	}
	public void clickSubmitButton(){
		button.submit();
	}
}