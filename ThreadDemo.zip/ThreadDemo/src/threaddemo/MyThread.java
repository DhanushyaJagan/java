package threaddemo;

public class MyThread extends Thread {

	public MyThread() {
		super();
	}

	public MyThread(String name) {
		super(name);
	}


	@Override
	public void run() {
		if(this.getName().equals("thraed-1")){
			for(int i=0;i<100;i++)
				if(i%2!=0)
					System.out.println(i);
		}
		else if(this.getName().equals("thraed-0"))
			for(int i=0;i<100;i++){
				if(i%2==0)
					System.out.println(i);	
			}

	}

}

