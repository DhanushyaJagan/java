package threaddemo.main;

import threaddemo.MyThread;

public class MainClass {
	public static void main(String[] args) {

MyThread th1=new MyThread("thread-1");
MyThread th2=new MyThread("thread-0");
th1.start();
th2.start();
	}
}
