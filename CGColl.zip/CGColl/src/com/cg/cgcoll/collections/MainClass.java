package com.cg.cgcoll.collections;

import com.cg.cgcoll.beans.ListClassDemo;

public class MainClass {

	public static void main(String[] args) {
	
		ListClassDemo.arrayListClassWork();

	}

}
