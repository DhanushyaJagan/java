package com.cg.cgcoll.beans;

import java.util.ArrayList;
import java.util.Collections;

import com.cg.cgcoll.collections.CustomerComparator;

public class ListClassDemo {
	public static void arrayListClassWork(){
		ArrayList<Customer> customerList=new ArrayList<>();
		customerList.add(new Customer(3466, "DHANU", "JAGAN"));
		customerList.add(new Customer(3457, "NIMMI", "JAGAN"));
		customerList.add(new Customer(3459, "SOWMI", "JAGAN"));

		customerList.add(new Customer(3456, "JAGAN", "RAMASAMY"));
		
		Collections.sort(customerList);
		Collections.sort(customerList,new CustomerComparator());

		for (Customer customer : customerList) {
			System.out.println(customer);
		}
		
	}

}
