package com.cg.payroll.exception;

public class PayrollServiceDownException extends Exception{
 public PayrollServiceDownException(){
	 super();
 }
 public PayrollServiceDownException(String message,Throwable cause, boolean enableSuppression,boolean writableStackTrace){
	 super(message,cause,enableSuppression,writableStackTrace);
 }
 public PayrollServiceDownException(String message,Throwable cause){
	 super(message,cause);
 }
 public PayrollServiceDownException(String message){
	 super(message);
 }
 public PayrollServiceDownException(Throwable cause){
	 super(cause);
 }
}
