package com.cg.payroll.test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.BDDMockito.Then;
import org.mockito.internal.stubbing.answers.Returns;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOService;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.PayrollServiceDownException;
import com.cg.payroll.services.PayrollService;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollTest {
	private static PayrollService payrollservices;
	private static PayrollDAOService mockdaoservices;

	@BeforeClass
	public static void setUpPayrollService(){
		mockdaoservices=Mockito.mock(PayrollDAOService.class);
		payrollservices=new PayrollServicesImpl(mockdaoservices);

	}
	@Before
	public void setUpTestData(){
	Associate associate1=new Associate(10001, 9090, "DHANU", "JAGAN", "JAVA", "SE", "JHUY78", "DHAN@HJ.COM", new Salary(20000, 800, 800), new BankDetails(22334567, "hdfc", "ifgdb"));
	Associate associate2=new Associate(10002, 9090, "SOWMI", "JAGAN", "JAVA", "SE", "JHUY78", "DHAN@HJ.COM", new Salary(20000, 800, 800), new BankDetails(22334567, "hdfc", "ifgdb"));
	//ArrayList<Associate> associatelist=new ArrayList<>();
	HashMap<Integer, Associate> associatelist=new HashMap<>();
	associatelist.put(10001,associate1);
	associatelist.put(10002,associate2);
	
	Mockito.when(mockdaoservices.getassociate(10001)).thenReturn(associate1);
	Mockito.when(mockdaoservices.getassociate(10002)).thenReturn(associate2);
	Mockito.when(mockdaoservices.insertAssociate(associate2)).thenReturn(10002);
	Mockito.when(mockdaoservices.insertAssociate(associate1)).thenReturn(10001);
	
	//Mockito.verify(mockdaoservices).getassociate(10001).getAssociateID();
	//Mockito.when(mockdaoservices.getassociate(1011)).thenReturn(null);

t
	public void testAcceptAssociateDetailsForValidData()throws AssociateDetailsNotFoundException{
		int expectedId=10001;
		int actualId=payrollservices.acceptAssociateDetails(9090, "DHANU", "JAGAN", "JAVA", "SE", "JHUY78", "DHAN@HJ.COM", 20000, 800, 800, 22334567, "hdfc", "ifgdb");
		assertEquals(expectedId, actualId);

	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidData()throws AssociateDetailsNotFoundException{
		Assert.assertEquals(10001, payrollservices.getAssociateDetails(115));

	}
	
	
	
	
	@Test
	public void testGetAssociateDetailsForvalidData()throws AssociateDetailsNotFoundException,PayrollServiceDownException{
		
	}

	@Test
	public void calculateNetSalaryForValidData()throws AssociateDetailsNotFoundException{
		int a=(int)payrollservices.calculateNetSalary(111);
		Assert.assertEquals(674213, a);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void calculateNetSalaryForInValidId()throws AssociateDetailsNotFoundException{
		
	}
	@After
	public void testDownMockData(){
		//PayrollDAOServicesImpl.associates.clear();
	}
	@AfterClass
	public static void setup(){

	}
}
