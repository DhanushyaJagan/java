package com.cg.project;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.LoginPage;

public class LoginPageTest {
	static WebDriver driver;
	private LoginPage loginPage;
	@BeforeClass
	public static void setUpDriverEnv(){
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Before
	public void setUpTestEnv(){
		driver.get("https://github.com/login");
		loginPage=new LoginPage();
		PageFactory.initElements(driver, loginPage);
	}
	@Test
	public void testForBlankUserNameAndPassword(){
		loginPage.setUserName("");
		loginPage.setPassword("");
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		String expectedErrorMessage="Incorrect username or password.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForInvalidUserNameAndValidPassword(){
		loginPage.setUserName("dhanushya.jaganathan@capgemini.com");
		loginPage.setPassword("");
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		String expectedErrorMessage="Incorrect username or password.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForValidUserNameAndInvalidPassword(){
		loginPage.setUserName("");
		loginPage.setPassword("dhanushya28");
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		String expectedErrorMessage="Incorrect username or password.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForValidUserNameAndValidPassword(){
		loginPage.setUserName("dhanushya.jaganathan@capgemini.com");
		loginPage.setPassword("dhanushya28");
		loginPage.clickSubmitButton();

	}
	@After
	public void setDownTestEnv(){
		loginPage=null;
	}
	@AfterClass
	public static void setDownDriverEnv(){
		driver.close();
	}
}


