package com.cg.project;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.RegistrationPage;


public class RegistrationPageTest {
	static WebDriver driver;
	private RegistrationPage registrationPage;
	@BeforeClass
	public static void setUpDriverEnv(){
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Before
	public void setUpTestEnv(){
		driver.get("https://github.com/join");
		registrationPage=new RegistrationPage();
		PageFactory.initElements(driver, registrationPage);
	}
	@Test
	public void testForBlankUserNameAndPasswordAndEmail(){
		registrationPage.setUserName("");
		registrationPage.setPassword("");
		registrationPage.setEmail("");
		registrationPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")).getText();
		String expectedErrorMessage="There were problems creating your account.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForValidUserNameAndValidPasswordAndInvalidEmail(){
		registrationPage.setUserName("dhanu");
		registrationPage.setPassword("dhanush28");
		registrationPage.setEmail("");
		registrationPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")).getText();
		String expectedErrorMessage="There were problems creating your account.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForValidBUserNameAndInvalidPasswordAndValidEmail(){
		registrationPage.setUserName("dhanu");
		registrationPage.setPassword("");
		registrationPage.setEmail("dhanu@gmail.com");
		registrationPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")).getText();
		String expectedErrorMessage="There were problems creating your account.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForInvalidUserNameAndValidPasswordAndValidEmail(){
		registrationPage.setUserName("");
		registrationPage.setPassword("DHANUSHYA");
		registrationPage.setEmail("dhanu@gmail.com");
		registrationPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")).getText();
		String expectedErrorMessage="There were problems creating your account.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForValidUserNameAndValidPasswordAndValidEmail(){
		registrationPage.setUserName("dhanushyaaaaabbbbbba");
		registrationPage.setPassword("ooooooooo1");
		registrationPage.setEmail("dhanusow1234@gmail.com");
		registrationPage.clickSubmitButton();
	}
	@After
	public void setDownTestEnv(){
		registrationPage=null;
	}
	@AfterClass
	public static void setDownDriverEnv(){
		driver.close();

	}
}
