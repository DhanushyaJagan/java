package com.cg.banking.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Transaction;
import com.cg.banking.beans.Account;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesAccount;
import com.cg.banking.daoservices.BankingDAOServicesCustomer;
import com.cg.banking.daoservices.BankingDAOServicesTransaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.utlility.BankingUtility;
public class BankingServicesImpl implements BankingServices { 
	
	@Autowired
	private BankingDAOServicesCustomer daoServicesCustomer;
	@Autowired
	private BankingDAOServicesAccount daoServicesAccount;
	@Autowired
	private BankingDAOServicesTransaction daoServicesTransaction;
//	private BankingDAOServicesImpl daoServicesImpl;
//	public BankingServicesImpl() {
//		daoServicesImpl=new BankingDAOServicesImpl();
//	}
	@Transactional(propagation=Propagation.REQUIRED)

	//@Transactional(value=TxType.REQUIRED)
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode)throws BankingServicesDownException{
		Customer customer=daoServicesCustomer.save(new Customer(firstName, lastName, emailId, panCard, new Address(localAddressPinCode, localAddressCity, localAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
		return customer.getCustomerId();
	}
	@Transactional(propagation=Propagation.REQUIRED)

	//@Transactional(value=TxType.REQUIRED)
	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
	CustomerNotFoundException,
	InvalidAccountTypeException,
	BankingServicesDownException{
		if(initBalance<0)
			throw new InvalidAmountException("Please enter valid amount >0");
		if(daoServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(accountType.equalsIgnoreCase("savings")||accountType.equalsIgnoreCase("current")||accountType.equalsIgnoreCase("salary")) {
			Customer customer=daoServicesCustomer.findOne(customerId);
		//	System.out.println(customer);
			Account account=new Account(accountType, initBalance);
			account.setCustomer(customer);
			account.setAccountType(accountType);
			account.setAccountBalance(initBalance);
			daoServicesAccount.save(account);
		return account.getAccountNo();
		}
		else
			throw new InvalidAccountTypeException("Account type is invalid");
	}
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public float depositAmount(int customerId, long accountNo, float amount)throws CustomerNotFoundException,
	AccountNotFoundException,BankingServicesDownException, AccountBlockedException {
	
		if(daoServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		
		if(daoServicesAccount.findOne((int) accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		if(daoServicesAccount.findOne((int) accountNo).getStatus()=="Blocked")
			throw new AccountBlockedException("Your account is currently blocked. Please contact with your bank");
		if(amount<0)
			try {
				throw new InvalidAmountException("Please enter valid amount >0");
			} catch (InvalidAmountException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		//getAccountAllTransaction(customerId, accountNo)[getAccountDetails(customerId, accountNo).getTransactionIdxCounter()-1].setTransactionType("Deposit");
		Account account=daoServicesAccount.findOne((int) accountNo);
		if(customerId==account.getCustomer().getCustomerId()) {
			account=daoServicesAccount.findOne((int) accountNo);
			account.setAccountBalance(account.getAccountBalance()+amount);
			daoServicesAccount.saveAndFlush(account);
			Transaction transaction=new Transaction(amount, "Deposit");
			
			transaction.setAccount(account);
			//transaction.setAmount(amount);
			//transaction.setTransactionType("Deposit");
			daoServicesTransaction.save(transaction);
			System.out.println(transaction);
			//daoServicesTransaction.flush();
		
			return this.getAccountDetails(customerId, accountNo).getAccountBalance();
		}
		//this.getAccountDetails(customerId, accountNo).setAccountBalance(this.getAccountDetails(customerId, accountNo).getAccountBalance()+amount);
		return 0;
	}
	@org.springframework.transaction.annotation.Transactional(propagation=Propagation.REQUIRED)
	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)throws InsufficientAmountException,CustomerNotFoundException,
	AccountNotFoundException,InvalidPinNumberException,
	BankingServicesDownException ,AccountBlockedException {
		Customer customer=daoServicesCustomer.findOne(customerId);
		Account account=customer.getAccountMap().get(accountNo);
		if(customer==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		if(account.getStatus()=="Blocked")
			throw new AccountBlockedException("Your account is currently blocked. Please contact your Bank");
		if(amount<0)
			throw new InvalidAmountException("Please enter valid amount >0");
		while(account.getPinCounter()<3){
			
			if(account.getPinNumber()==pinNumber&&account.getAccountBalance()>amount){
				if(customerId==account.getCustomer().getCustomerId()) {
				//	account=daoServicesAccount.findOne(accountNo);
					account.setAccountBalance(account.getAccountBalance()-amount);
					daoServicesAccount.saveAndFlush(account);
					Transaction transaction=new Transaction(amount, "Withdrawl");
				
					transaction.setAccount(account);
					//transaction.setAmount(amount);
					//transaction.setTransactionType("Withdrawl");
					daoServicesTransaction.save(transaction);
					System.out.println(transaction);
					//daoServicesTransaction.flush();
					
					return this.getAccountDetails(customerId, accountNo).getAccountBalance();
				}
				
				
				
//				daoServices.insertTransaction(customerId, accountNo, new Transaction(amount,"Withdraw"));
//				this.getAccountDetails(customerId, accountNo).setAccountBalance(this.getAccountDetails(customerId, accountNo).getAccountBalance()-amount);
//				getAccountDetails(customerId, accountNo).setPinCounter(0);
				
				
				//getAccountAllTransaction(customerId, accountNo)[getAccountDetails(customerId, accountNo).getTransactionIdxCounter()-1].setTransactionType("Withdraw");
				//getAccountDetails(customerId, accountNo).getTransactionMap();
				//System.out.println(this.getAccountDetails(customerId, accountNo).getAccountBalance()+"return amt");
				return 0;
			}
			getAccountDetails(customerId, accountNo).setPinCounter(getAccountDetails(customerId, accountNo).getPinCounter()+1);
			if(	getAccountDetails(customerId, accountNo).getPinCounter()>=3)
				getAccountDetails(customerId, accountNo).setStatus("Blocked");
			if(getAccountDetails(customerId, accountNo).getPinNumber()!=pinNumber)
				throw new InvalidPinNumberException("You entered incorrect pin. Entering wrong pin 3 times will make your account blocked");
			if(getAccountDetails(customerId, accountNo).getAccountBalance()<amount)
				throw new InsufficientAmountException("Your account has insuffcient balance :"+" "+this.getAccountDetails(customerId, accountNo).getAccountBalance());	

		}
		return 0;
	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException,
	CustomerNotFoundException,
	AccountNotFoundException,InvalidPinNumberException,
	BankingServicesDownException, AccountBlockedException{
	Customer customer=daoServicesCustomer.findOne(customerIdTo);
	Account account=customer.getAccountMap().get(accountNoTo);
		if(customer==null)
			//return true;
			throw new CustomerNotFoundException();
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		if(transferAmount<0)
			throw new InvalidAmountException("Please enter valid amount >0");
	
		if(withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber)==0)
			return false;

			depositAmount(customerIdTo, accountNoTo, transferAmount);
		return true;


	}

	@Override
	public Customer getCustomerDetails(int customerId)throws CustomerNotFoundException,BankingServicesDownException {
		if(daoServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		return daoServicesCustomer.findOne(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo)throws 
	CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException {
		if(daoServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		Customer customer=daoServicesCustomer.findOne(customerId);
		Account account=customer.getAccountMap().get(accountNo);
		if(daoServicesAccount.findOne((int) account.getAccountNo())==null)
			throw new AccountNotFoundException("Account not found");
		return daoServicesAccount.findOne((int) account.getAccountNo());
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)throws
	CustomerNotFoundException,AccountNotFoundException ,
	BankingServicesDownException {
		if(daoServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		Customer customer=daoServicesCustomer.findOne(customerId);
		Account account=customer.getAccountMap().get(accountNo);
		if(daoServicesAccount.findOne((int) account.getAccountNo())==null)
			throw new AccountNotFoundException("Account not found");
		account.setPinNumber(BankingUtility.rand.nextInt(9999));
		daoServicesAccount.saveAndFlush(account);
		return account.getPinNumber();
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)throws CustomerNotFoundException,
	AccountNotFoundException,
	InvalidPinNumberException,BankingServicesDownException {
		Customer customer=daoServicesCustomer.findOne(customerId);
		Account account=customer.getAccountMap().get(accountNo);
		if(customer==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		if(account.getPinNumber()==oldPinNumber){
			account.setPinNumber(newPinNumber);
			daoServicesAccount.saveAndFlush(account);
			return true;
		}
		else
			throw new InvalidPinNumberException("You entered incorrect pin");

		//return false;
	}

	@Override
	public List<Customer> getAllCustomerDetails()throws BankingServicesDownException {

		return daoServicesCustomer.findAll();
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)throws BankingServicesDownException,CustomerNotFoundException {
		Customer customer=daoServicesCustomer.findOne(customerId);
		Map<Long, Account>account =(Map<Long, Account>) customer.getAccountMap();
		List<Account> list = new ArrayList<Account>(account.values());
		return list;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException {
		Customer customer=daoServicesCustomer.findOne(customerId);
		Account account=customer.getAccountMap().get(accountNo);
		if(customer==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		Map<Integer,Transaction> transaction=account.getTransactionMap();
		List<Transaction> list=new ArrayList<>(account.getTransactionMap().values());
		return list;
	}
	@Override
	public String accountStatus(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException, AccountBlockedException {
		Customer customer=daoServicesCustomer.findOne(customerId);
		Account account=customer.getAccountMap().get(accountNo);
		if(customer==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		if(account.getStatus()=="Blocked")
			throw new AccountBlockedException("Your account is currently blocked. Please contact your Bank");
		return account.getStatus();
	}
	public boolean deleteAccount(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException{
		Customer customer=daoServicesCustomer.findOne(customerId);
		Account account=customer.getAccountMap().get(accountNo);
		if(customer==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		daoServicesAccount.delete(account);
		return true;
	}
	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException,
			AccountNotFoundException {
		// TODO Auto-generated method stub
		return false;
	}
	}

	/*private BankingDAOServices daoservices;
	public BankingServicesImpl() {
	}
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public int acceptCustomerDetails(String firstName, String lastName,
			String customerEmailId, String panCard, String localAddressCity,
			String localAddressState, int localAddressPinCode,
			String homeAddressCity, String homeAddressState,
			int homeAddressPinCode) throws BankingServicesDownException {
		Customer customer= daoservices.save(new Customer(firstName, lastName,customerEmailId, panCard,new Address(localAddressPinCode, localAddressCity, localAddressState),new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
	return customer.getCustomerId();
	}
	
	@Override
	public long openAccount(int customerId, String accountType,
			float initBalance) {
		return daoservices.save( new Account(accountType, initBalance));
	}
	
	@Override
	public float depositAmount(int customerId, long accountNo, float amount)throws CustomerNotFoundException,
	AccountNotFoundException,BankingServicesDownException, AccountBlockedException {
		daoservices.save(customerId, accountNo, new Transaction(amount));
		this.getAccountDetails(customerId, accountNo).setAccountBalance(getAccountDetails(customerId, accountNo).getAccountBalance()+amount);
		getAccountDetails(customerId, accountNo).setStatus("ACTIVE");
		return this.getAccountDetails(customerId, accountNo).getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount,
			int pinNumber)throws InsufficientAmountException,CustomerNotFoundException,
			AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException ,AccountBlockedException {
		//if(pinNumber==getAccountDetails(customerId, accountNo).getPinNumber())
		//if(getAccountDetails(customerId, accountNo).getPinCounter()<3)
		//if(amount<daoservices.getAccount(customerId, accountNo).getAccountBalance())
		while(getAccountDetails(customerId, accountNo)!=null&&getAccountDetails(customerId, accountNo).getPinCounter()<3){
			if(pinNumber==getAccountDetails(customerId, accountNo).getPinNumber()) {
				if(amount<=daoservices.getAccount(customerId, accountNo).getAccountBalance()) {
					daoservices.insertTransaction(customerId, accountNo, new Transaction(amount));
					float totalBalance=this.getAccountDetails(customerId, accountNo).getAccountBalance()-amount;
					this.getAccountDetails(customerId, accountNo).setAccountBalance(totalBalance);
					getAccountDetails(customerId, accountNo).setPinCounter(0);
					return this.getAccountDetails(customerId, accountNo).getAccountBalance();
				}
				getAccountDetails(customerId, accountNo).setPinCounter(getAccountDetails(customerId, accountNo).getPinCounter()+1);
			}
			else if(getAccountDetails(customerId, accountNo).getPinCounter()>=3) {
				getAccountDetails(customerId, accountNo).setStatus("Blocked");
				return -1;
			}
			else
				return 0;
		}
		return 0;
	}
	@Transactional

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo,
			int customerIdFrom, long accountNoFrom, float transferAmount,
			int pinNumber) throws InsufficientAmountException,
			CustomerNotFoundException,
			AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		if(pinNumber==daoservices.getAccount(customerIdFrom, accountNoFrom).getPinNumber());
		if(transferAmount<=daoservices.getAccount(customerIdFrom, accountNoFrom).getAccountBalance());
				float totalBalanceTo=daoservices.getAccount(customerIdTo, accountNoTo).getAccountBalance()+transferAmount;
				daoservices.getAccount(customerIdTo, accountNoTo).setAccountBalance(totalBalanceTo);
				float totalBalanceFrom=daoservices.getAccount(customerIdFrom, accountNoFrom).getAccountBalance()-transferAmount;
				daoservices.getAccount(customerIdFrom, accountNoFrom).setAccountBalance(totalBalanceFrom);
				return true;		
				
	}
	@Transactional

	@Override
	public Customer getCustomerDetails(int customerId)throws CustomerNotFoundException,BankingServicesDownException {
return daoservices.getCustomer(customerId);		
	}
	@Transactional

	@Override
	public Account getAccountDetails(int customerId, long accountNo)throws	CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException {
		return daoservices.getAccount(customerId, accountNo);
	}
	@Transactional

	@Override
	public int generateNewPin(int customerId, long accountNo) throws
	CustomerNotFoundException,AccountNotFoundException ,
	BankingServicesDownException{
		return daoservices.generatePin(customerId, this.getAccountDetails(customerId, accountNo));
	}
	@Transactional

	@Override
	public boolean changeAccountPin(int customerId, long accountNo,
			int oldPinNumber, int newPinNumber)throws CustomerNotFoundException,
			AccountNotFoundException,
			InvalidPinNumberException,BankingServicesDownException  {
		if(oldPinNumber==daoservices.getAccount(customerId, accountNo).getPinNumber());
		oldPinNumber=newPinNumber;
		daoservices.getAccount(customerId, accountNo).setPinNumber(oldPinNumber);
		return true;
	}
	@Transactional

	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException{

		return daoservices.getCustomers();
	}
	@Transactional

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)throws BankingServicesDownException,CustomerNotFoundException {
		return daoservices.getAccounts(customerId);
	}
	@Transactional

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException {
		return daoservices.getTransactions(customerId, accountNo);
	}
	@Transactional

	@Override
	public String accountStatus(int customerId, long accountNo)	throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException, AccountBlockedException {
		return daoservices.getAccount(customerId, accountNo).getStatus();
	}
	@Transactional

	@Override
	public boolean closeAccount(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException {
		if(daoservices.getAccount(customerId, accountNo).getAccountBalance()==0){
			daoservices.deleteAccount(customerId, accountNo);
		return true;
		}
		return false;
	}
}*/
