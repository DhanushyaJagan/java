package com.cg.banking.beans;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
public class Account {
	private int pinNumber,pinCounter;
	private String accountType,status;
	private float accountBalance;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long accountNo;	
	@ManyToOne
	private Customer customers;
	@OneToMany(mappedBy="accounts")
	private static int TRANSACTION_IDX=0;
	HashMap<Integer,Transaction> transactions=new HashMap<Integer,Transaction>();
	public Account() {}
	public Account(String accountType, float accountBalance) {
		super();
		this.accountType = accountType;
		this.accountBalance = accountBalance;
	}
	public Account(int pinNumber, int pinCounter, String accountType,
			String status, float accountBalance, long accountNo,
			HashMap<Integer, Transaction> transactions) {
		super();
		this.pinNumber = pinNumber;
		this.pinCounter = pinCounter;
		this.accountType = accountType;
		this.status = status;
		this.accountBalance = accountBalance;
		this.accountNo = accountNo;
		this.transactions = transactions;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public int getPinCounter() {
		return pinCounter;
	}
	public void setPinCounter(int pinCounter) {
		this.pinCounter = pinCounter;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public static int getTRANSACTION_IDX() {
		return TRANSACTION_IDX;
	}
	public static void setTRANSACTION_IDX(int tRANSACTION_IDX) {
		TRANSACTION_IDX = tRANSACTION_IDX;
	}
	public HashMap<Integer, Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(HashMap<Integer, Transaction> transactions) {
		this.transactions = transactions;
	}
	@Override
	public String toString() {
		return "Account [pinNumber=" + pinNumber + ", pinCounter=" + pinCounter
				+ ", accountType=" + accountType + ", status=" + status
				+ ", accountBalance=" + accountBalance + ", accountNo="
				+ accountNo + ", transactions=" + transactions + "]";
	}
	public void setCustomer(Customer customer) {
		this.customers=customer;
	}
	public Customer getCustomer() {
		return customers;
	}
	public Map<Integer, Transaction> getTransactionMap() {
		// TODO Auto-generated method stub
		return null;
	}
}