package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.BasicClass;

@WebServlet("/PlaceServlet")
public class PlaceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletContext context;
    public PlaceServlet() {
        super();
    }
	
	public void init()  {
		context = getServletContext();
	}

	
	public void destroy() {
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstName=(String)request.getParameter("firstName");
		String lastName=(String)request.getParameter("lastName");
		BasicClass basicClass = new BasicClass(firstName, lastName);
		
		context.setAttribute("basicClass", basicClass);
		PrintWriter writer=response.getWriter();
		writer.println("<html>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("</br>");
		writer.println("<form action='CommServlet' method='post'>");
		//writer.println("<table>");
		//writer.println("<tr>");
		writer.println("<td>firstName:</td>"+basicClass.getFirstName());
		writer.println("</br>");
		//writer.println("</tr>");
		//writer.println("<tr>");
		writer.println("<td>lastName:</td>"+basicClass.getLastName());
		writer.println("</br>");
		//writer.println("</tr>");
		//writer.println("<tr>");
		writer.println("<td>city</td>");
		writer.println("<td><input type='text' name='city'></td>");
		writer.println("</br>");

		//writer.println("</tr>");
	//	writer.println("<tr>");
		writer.println("<td>state</td>");
		writer.println("<td><input type='text' name='state'></td>");
		writer.println("</br>");

		//writer.println("</tr>");
		//writer.println("<tr>");
		writer.println("<td><input type='submit' value='submit'></td>");
		//writer.println("</tr>");
		writer.println("</form>");
		//writer.println("</table>");
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");
		}
	
	}


