package com.cg.wrap.beans;

public class Innn {
int num=100;

public Innn() {
	super();
}

public Innn(int num) {
	super();
	this.num = num;
}

public int getNum() {
	return num;
}

public void setNum(int num) {
	this.num = num;
}

}
