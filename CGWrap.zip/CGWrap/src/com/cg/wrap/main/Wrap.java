package com.cg.wrap.main;
import com.cg.wrap.beans.Innn;
public class Wrap {

	public static void main(String[] args) {
int num=100;
Innn n =new Innn();
System.out.println(100);
	}

}
