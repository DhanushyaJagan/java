package com.cg.threadproject.main;

import com.cg.threadproject.thread.Customer;

public class MainClass {

	public static void main(String[] args) {
Thread th1= new Thread(new Customer(),"rahul");
Thread th2= new Thread(new Customer(),"anil");
Thread th3= new Thread(new Customer(),"sathish");
th1.start();
th2.start();
th3.start();
	}

}
