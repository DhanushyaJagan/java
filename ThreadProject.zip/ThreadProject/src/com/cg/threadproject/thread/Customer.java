package com.cg.threadproject.thread;

import com.cg.threadproject.beans.Account;


public class Customer implements Runnable{

	public Customer() {
		super();
	}
private static Account account;
static{
account =new Account(10000);
System.out.println("inity bal"+account.getBalance());

}
	@Override
	public void run() {
		Thread customerThread = Thread.currentThread();
		if(customerThread.getName().equals("rahul")){
				for(int i=1;i<10;i++){
					try{
						Thread.sleep(0);
						System.out.println("\nRahul has call withdrawl"+i+"time balance="+account.withdraw(3000));
					}catch(InterruptedException e){
						e.printStackTrace();
					}
				}
	}
	if(customerThread.getName().equals("anil")){
	for(int i=1;i<10;i++){
		try{
			Thread.sleep(0);
			System.out.println("\nanil has call deposit"+i+"time balance="+account.deposit(2000));
		}catch(InterruptedException e){
			e.printStackTrace();
		}
	}
}
	if(customerThread.getName().equals("sathish")){
	for(int i=1;i<10;i++){
		try{
			Thread.sleep(0);
			System.out.println("\nsathish has call checkBalance"+i+"time balance="+account.getBalance());
		}catch(InterruptedException e){
			e.printStackTrace();
		}
	}
}
}
}
