package com.cg.project.views;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/SuccessServlet")
public class SuccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public SuccessServlet() {
        super();
    }

	
	public void init(ServletConfig config) throws ServletException {
	}

	
	public void destroy() {
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
String username=(String) request.getAttribute("username");
String password=(String) request.getAttribute("password");
PrintWriter writer=response.getWriter();
	writer.println("<html>");
	writer.println("<head>");
	writer.println("<body>");
	writer.println("<div align='center'>");
	writer.println("<font color='green' size=15>");
	writer.println("WELCOME username:"+username);
	writer.println("<br/>");
	writer.println("password:"+password);
	writer.println("</body>");
	writer.println("</head>");
	writer.println("</html>");
	}
	
	}

	
