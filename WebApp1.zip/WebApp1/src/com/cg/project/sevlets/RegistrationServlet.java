package com.cg.project.sevlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public RegistrationServlet() {
        super();
    }

	public void init(ServletConfig config) throws ServletException {
		System.out.println("init(ServletConfig config)");
	}

	public void destroy() {
		System.out.println("destroy()");
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	System.out.println("service()");
	PrintWriter writer=response.getWriter();
	String FirstName=request.getParameter("FirstName");
	String LastName=request.getParameter("LastName");
	String username=request.getParameter("username");
	String password=request.getParameter("password");
	String ReEnterpassword=request.getParameter("ReEnterpassword");
	String MobileNumber=request.getParameter("MobileNumber");
	String Email=request.getParameter("Email");
	String gender=request.getParameter("gender");
	String [] communication=request.getParameterValues("communication");
	String graduation=request.getParameter("graduation");
	String file=request.getParameter("file");
	System.out.println("FirstName:"+FirstName);
	System.out.println("LastName:"+LastName);
	System.out.println("username:"+username);
	System.out.println("password:"+password);
	System.out.println("ReEnterpassword:"+ReEnterpassword);
	System.out.println("MobileNumber:"+MobileNumber);
	System.out.println("Email:"+Email);
	System.out.println("gender:"+gender);
	System.out.println("communication:"+communication);
	System.out.println("graduation:"+graduation);
	System.out.println("file:"+file);
	writer.println("<html>");
	writer.println("<head>");
	writer.println("<body>");
	writer.println("<div align='center'>");
	writer.println("<font color='red' size=15>");
	writer.println(" FirstName:"+FirstName);
	writer.println("<br/>");
	writer.println("LastName:"+LastName);
	writer.println("<br/>");
	writer.println("username:"+username);
	writer.println("<br/>");
	writer.println("password:"+password);
	writer.println("<br/>");
	writer.println("ReEnterpassword:"+ReEnterpassword);
	writer.println("<br/>");
	writer.println("MobileNumber:"+MobileNumber);
	writer.println("<br/>");
	writer.println("Email:"+Email);
	writer.println("<br/>");
	writer.println("gender:"+gender);
	writer.println("<br/>");
	writer.println("communication:"+communication);
	writer.println("<br/>");
	writer.println("graduation:"+graduation);
	writer.println("<br/>");
	writer.println("file:"+file);	
	writer.println("</body>");
	writer.println("</head>");
	writer.println("</html>");


	}

	

}
