package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;
	public LoginServlet() {
		super();
	}
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init(ServletConfig config)");
		ServletContext servletContext=getServletContext();
		con=(Connection)servletContext.getAttribute("con");
	}
	public void destroy() {
		System.out.println("destroy()");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("service()");
		//PrintWriter writer=response.getWriter();
		try
		{
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			RequestDispatcher dispatcher;
			UserBean userbean=new UserBean(username,password);
			PreparedStatement pstmt =con.prepareStatement("Select password from userBean where userName=?");
			pstmt.setString(1,	userbean.getUsername());
			if((username.equals("dhanu")&&(password.equals("dhanu")))){
				dispatcher=request.getRequestDispatcher("SuccessPage.jsp");
				request.setAttribute("username", username);
				request.setAttribute("password", password);
				dispatcher.forward(request, response);

				/*	System.out.println("username:"+username+" "+"password:"+password);
				if((username.equals("dhdhdhdh")&&(password.equals("helloworld")))){
				writer.println("<html>");
				writer.println("<head>");
				writer.println("<body>");
				writer.println("<div align='center'>");
				writer.println("<font color='green' size=15>");
				writer.println("WELCOME username:"+username);
				writer.println("<br/>");
				writer.println("password:"+password);
				writer.println("</body>");
				writer.println("</head>");
				writer.println("</html>");
				}
				else{
					writer.println("<html>");
					writer.println("<head>");
					writer.println("<body>");
					writer.println("<div align='center'>");
					writer.println("<font color='red' size=15>");
					writer.println("WELCOME username:"+username);
					writer.println("<br/>");
					writer.println("password:"+password);
					writer.println("</body>");
					writer.println("</head>");
					writer.println("</html>");
				}
				 */
			}
			else{
				dispatcher=request.getRequestDispatcher("ErrorPage.jsp");
				//request.setAttribute("username", username);
				request.setAttribute("errormsg", "sorry");

				//request.setAttribute("password", password);
				dispatcher.forward(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
