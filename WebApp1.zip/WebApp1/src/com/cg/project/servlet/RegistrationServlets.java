package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;

@WebServlet("/RegistrationServlets")
public class RegistrationServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String gender;
	private Connection con;
	public RegistrationServlets() {
		super();
	}
	public void init(ServletConfig config) throws ServletException {
		ServletContext servletContext=getServletContext();
		con=(Connection)servletContext.getAttribute("con");
	}
	public void destroy() {
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		super.doGet(req, resp);
		resp.getWriter().append("sERVED AT").append(req.getContextPath());
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		super.doPost(req, resp);
		String firstname=req.getParameter("firstname");
		String lastname=req.getParameter("lastname");

		String username=req.getParameter("username");
		String password=req.getParameter("password");
		String mobileNumber=req.getParameter("mobileNumber");
		String email=req.getParameter("email");
		String getgender=req.getParameter("gender");
		//String communication=req.getParameter("communication");
		//String graduation=req.getParameter("graduation");
		String descriprtion=req.getParameter("descriprtion");
		String filename=req.getParameter("filename");
		if("male".equals(getgender))	{
			gender="male";
		}	
		else if("female".equals(getgender)){
			gender="female";
		}
		String[] communicationarray=req.getParameterValues("communication");
		String graduation=req.getParameter("graduation");
		RequestDispatcher dispatcher;
		UserBean userBean=new UserBean(firstname, lastname, username, password, mobileNumber, email, getgender, graduation, descriprtion);
		PrintWriter writer=resp.getWriter();
		if(username.equals(password)){
			try{
				con.setAutoCommit(false);
				PreparedStatement pstmt=con.prepareStatement("insert into UserBean(username,password,firstname,lastname,mobileNumber,email,getgender,graduation,descriprtion)");
				pstmt.setString(1,username);
				pstmt.setString(2,password);
				pstmt.setString(3,firstname);
				pstmt.setString(4,lastname);
				pstmt.setString(5,mobileNumber);
				pstmt.setString(6,email);
				pstmt.setString(7,gender);
				pstmt.setString(8,graduation);
				pstmt.setString(9,descriprtion);
				pstmt.executeUpdate();
				con.commit();
				dispatcher =req.getRequestDispatcher("SuccessServlet");
				req.setAttribute("UserBean",userBean);
				dispatcher.forward(req, resp);
			}
			catch(SQLException e){
				try{
					con.rollback();
				}catch (SQLException e1){
					e1.printStackTrace();
				}
				throw new ServletException(e);
			}

			finally{
				try{
					con.setAutoCommit(true);
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
		}
		else if(!username.equals(password))	
		{
			dispatcher=req.getRequestDispatcher("ErrorServlet");
			req.setAttribute("errormssg", "try again");
			dispatcher.forward(req, resp);
		}
	}
}







/*PrintWriter writer=response.getWriter();
		String FirstName=request.getParameter("firstName");
		String LastName=request.getParameter("lastName");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String ReEnterpassword=request.getParameter("re-enterpassword");
		String MobileNumber=request.getParameter("mobileNumber");
		String Email=request.getParameter("email");
		String gender=request.getParameter("gender");
		String [] communication=request.getParameterValues("communication");


		String Graduation=request.getParameter("graduation");
		String file=request.getParameter("filename");
		System.out.println("FirstName:"+FirstName);
		System.out.println("LastName:"+LastName);
		System.out.println("username:"+username);
		System.out.println("password:"+password);
		System.out.println("ReEnterpassword:"+ReEnterpassword);
		System.out.println("MobileNumber:"+MobileNumber);
		System.out.println("Email:"+Email);
		System.out.println("gender:"+gender);

		 for (int i=0;i<communication.length; i++) {
				System.out.println("communication:"+communication);

		  }
		System.out.println("<br>communication<ul> ");
	    for (int i=0;i<communication.length; i++) {
	    	writer.println("<li>" + communication[i]);
	  }
	    writer.println("</ul>");
		System.out.println("graduation:"+Graduation);

		System.out.println("file:"+file);
		writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("<font color='red' size=15>");
		writer.println(" FirstName:"+FirstName);
		writer.println("<br/>");
		writer.println("LastName:"+LastName);
		writer.println("<br/>");
		writer.println("username:"+username);
		writer.println("<br/>");
		writer.println("password:"+password);
		writer.println("<br/>");
		writer.println("ReEnterpassword:"+ReEnterpassword);
		writer.println("<br/>");
		writer.println("MobileNumber:"+MobileNumber);
		writer.println("<br/>");
		writer.println("Email:"+Email);
		writer.println("<br/>");
		writer.println("gender:"+gender);
		writer.println("<br>communication<ul> ");
	    for (int i=0;i<communication.length; i++) {
	    	writer.println(  communication[i]);
	  }
	    writer.println("</ul>");
		writer.println("<br/>");
		writer.println("graduation:"+Graduation);
		writer.println("<br/>");
		writer.println("file:"+file);	
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");

	}*/


