package com.cg.payroll.beans;
public class BankDetails {
	private int accountnumber;
	private String bankname,ifsccode;
	public BankDetails() {}
	public BankDetails(int accountnumber, String bankname, String ifsccode) {
		super();
		this.accountnumber = accountnumber;
		this.bankname = bankname;
		this.ifsccode = ifsccode;
	}
	public int getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	public String getIfsccode() {
		return ifsccode;
	}
	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountnumber;
		result = prime * result
				+ ((bankname == null) ? 0 : bankname.hashCode());
		result = prime * result
				+ ((ifsccode == null) ? 0 : ifsccode.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankDetails other = (BankDetails) obj;
		if (accountnumber != other.accountnumber)
			return false;
		if (bankname == null) {
			if (other.bankname != null)
				return false;
		} else if (!bankname.equals(other.bankname))
			return false;
		if (ifsccode == null) {
			if (other.ifsccode != null)
				return false;
		} else if (!ifsccode.equals(other.ifsccode))
			return false;
		return true;
	}
	
}
