package com.cg.payroll.main;
import java.io.ObjectInputStream.GetField;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollService;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
public class MainClass {
	
	

	public static void main(String[] args) {
	//	  Scanner scan = new Scanner(System.in);
		  
		Associate [] associates=new Associate[3];
		PayrollService payrollServices= new PayrollServicesImpl();
		int associateId= payrollServices.acceptAssociateDetails(2000, "Dhanu", "Jagan", "Java", "a4", "7686uy", "dhan@gmail.com", 2000, 2000,400000, 576784848, "hdfc", "78utu");
		//int associateId3= payrollServices.acceptAssociateDetails(2001, "SOWMI", "Jagan", "Java", "a4", "7686uy", "dhan@gmail.com", 2000, 2000,400000, 576784848, "hdfc", "78utu");
		//int associateId4= payrollServices.acceptAssociateDetails(2001, "SOWMI", "Jagan", "Java", "a4", "7686uy", "dhan@gmail.com", 2000, 2000,400000, 576784848, "hdfc", "78utu");
		//int associateId5= payrollServices.acceptAssociateDetails(2001, "SOWMI", "Jagan", "Java", "a4", "7686uy", "dhan@gmail.com", 2000, 2000,400000, 576784848, "hdfc", "78utu");

		System.out.println(associateId);
		//System.out.println(associateId3);
	//	System.out.println(associateId4);
		//System.out.println(associateId5);

		try {
			System.out.println(payrollServices.calculateNetSalary(associateId));
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
		try {
			System.out.println("ASSOCIATE");
			System.out.println(payrollServices.getAssociateDetails(associateId).getAssociateID()+" "+payrollServices.getAssociateDetails(associateId).getFirstName()+" "+payrollServices.getAssociateDetails(associateId).getLastName()+" "+payrollServices.getAssociateDetails(associateId).getDepartment()+" "+payrollServices.getAssociateDetails(associateId).getDesignation()+" "+payrollServices.getAssociateDetails(associateId).getYearlyInvestmentUnder80c()+" "+payrollServices.getAssociateDetails(associateId).getPancard()+" "+payrollServices.getAssociateDetails(associateId).getPancard());
			System.out.println("ASSOCIATE SALARY");
			System.out.println(payrollServices.getAssociateDetails(associateId).getSalary().getBasicsalary()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getAnnualsalary()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getAnnualtax()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getCompanypf()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getConveyenceallowance()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getEpf()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getGratutity()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getHra()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getGrosssalary()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getMonthlytax()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getNetsalary()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getPersonalallowance());
			System.out.println("ASSOCIATE BANK DETAILS");
			System.out.println(payrollServices.getAssociateDetails(associateId).getBankDetails().getAccountnumber()+" "+payrollServices.getAssociateDetails(associateId).getBankDetails().getBankname()+" "+payrollServices.getAssociateDetails(associateId).getBankDetails().getIfsccode());
		} 
		catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
		//try {
	//		System.out.println("ASSOCIATE");
	//		System.out.println(payrollServices.getAssociateDetails(associateId3).getAssociateID()+" "+payrollServices.getAssociateDetails(associateId3).getFirstName()+" "+payrollServices.getAssociateDetails(associateId3).getLastName()+" "+payrollServices.getAssociateDetails(associateId3).getDepartment()+" "+payrollServices.getAssociateDetails(associateId3).getDesignation()+" "+payrollServices.getAssociateDetails(associateId3).getYearlyInvestmentUnder80c()+" "+payrollServices.getAssociateDetails(associateId3).getPancard()+" "+payrollServices.getAssociateDetails(associateId3).getPancard());
		//	System.out.println("ASSOCIATE SALARY");
		//	System.out.println(payrollServices.getAssociateDetails(associateId3).getSalary().getBasicsalary()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getAnnualsalary()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getAnnualtax()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getCompanypf()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getConveyenceallowance()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getEpf()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getGratutity()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getHra()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getGrosssalary()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getMonthlytax()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getNetsalary()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getPersonalallowance());
		//	System.out.println("ASSOCIATE BANK DETAILS");
		//	System.out.println(payrollServices.getAssociateDetails(associateId3).getBankDetails().getAccountnumber()+" "+payrollServices.getAssociateDetails(associateId3).getBankDetails().getBankname()+" "+payrollServices.getAssociateDetails(associateId3).getBankDetails().getIfsccode());
		//} 
	//	catch (AssociateDetailsNotFoundException e) {
	//		e.printStackTrace();
	//	}
	

		
		//	associates[0]=new Associate(20000, "DHANU", "JAGAN", "JAVA", "A4", "7878UI", "dhanu@gmail.com", new Salary(19000, 2000, 2000), new BankDetails(34567789, "hdfc", "4900hdfc"));
	//	associates[1]=new Associate(30000, "nimmi", "JAGAN", "mf", "A4", "74677yh", "nimmi@gmail.com", new Salary(29000, 3000, 3000), new BankDetails(98766556, "hdfc", "4900hdfc"));
	//	associates[2]=new Associate(40000, "sowmi", "JAGAN", "sap", "A4", "7997uk", "sowmi@gmail.com", new Salary(39000, 4000, 4000), new BankDetails(57809900, "hdfc", "4900hdfc"));
		
		// Associate associate2=new Associate(3456, 666, "sowmi", "JAGAN", "mf", "MANAGER", "1234ER", "dhanu@gmail.com");
		//   Associate associate3=new Associate(5678, 765, "nimmi", "jagan", "java", "a4", "7645rt", "hjujk@gmail.com");
		// Associate associate4=new Associate(7688, 987, "JAGAN", "RAMASAMY", "TESTING", "SRMANAGER", "3467YU", "HFGH@GMAIL.COM");
		 
		// BankDetails bankDetails2=new BankDetails(1232456, "IFSC", "1246IFSC");
		// BankDetails bankDetails3=new BankDetails(12345, "ICICICI", "6889ici");
		// BankDetails bankDetails4=new BankDetails(789790, "CITY", "6899city");
		
		//  Salary salary2=new Salary(6565, 566, 896, 789, 561, 571, 587, 574, 478, 477, 445);
		//Salary salary3=new Salary(54545, 455, 555, 741, 552, 410, 775, 7774, 441, 879, 222);
		//	Salary salary4=new Salary(5885, 585, 474, 5414, 754, 455, 451, 77, 477, 455, 555);
		//System.out.println("ASSOCIATE DETAILS"+"  "+associate1.getAssociateID()+"  "+associate1.getYearlyInvestmentUnder80c()+" "+associate1.getDepartment()+"  "+associate1.getDesignation()+" "+associate1.getEmailid());
		//System.out.println("Banking Details"+"  "+bankDetails1.getAccountnumber()+" "+bankDetails1.getBankname()+" "+bankDetails1.getIfsccode());
		// 	System.out.println("Salary Details"+" "+salary1.getBasicsalary()+" "+salary1.getCompanypf()+" "+salary1.getConveyenceallowance()+" "+salary1.getEpf()+" "+salary1.getGratutity()+" "+salary1.getGrosssalary()+" "+salary1.getHra()+" "+salary1.getMonthlytax()+" "+salary1.getNetsalary()+" "+salary1.getOtherallowance()+" "+salary1.getPersonalallowance());




	}

}
