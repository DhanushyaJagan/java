package com.cg.payroll.daoservices;

import java.sql.SQLException;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.PayrollServicesDownException;

public interface PayrollDAOService {
	int insertAssociate(Associate associate) throws SQLException;

	boolean updateAssociate(Associate associate) throws PayrollServicesDownException, SQLException;

	boolean deleteAssociate(int associateID);

	Associate getAssociate(int associateID) throws PayrollServicesDownException, SQLException;

	List<Associate> getAssociates() throws SQLException;

}
