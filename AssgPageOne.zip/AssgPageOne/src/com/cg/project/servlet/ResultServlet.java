package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ResultServlet")
public class ResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public ResultServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void init(ServletConfig config) throws ServletException {
	}

	
	public void destroy() {
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String email=request.getParameter("email");
		String mobNo=request.getParameter("mobNo");
		PrintWriter writer=response.getWriter();
		writer.println("<html>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("</br>");
		writer.println("<form> ");
		writer.println("<td>firstName:</td>"+firstName);
		writer.println("</br>");
		writer.println("<td>lastName:</td>"+lastName);
		writer.println("</br>");
		writer.println("<td>city:</td>"+city);
		writer.println("</br>");
		writer.println("<td>state:</td>"+state);
		writer.println("</br>");
		writer.println("<td>email:</td>"+email);
		writer.println("</br>");
		writer.println("<td>mobNo:</td>"+mobNo);
		writer.println("</form>");
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");
		}
	
	}


