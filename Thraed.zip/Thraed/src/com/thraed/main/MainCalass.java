package com.thraed.main;

import threaddemo.MyThread;

public class MainCalass {

		MyThread th1=new MyThread("thread-1");
		MyThread th2=new MyThread("thread-0");

	}

}
