package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.BasicClass;

@WebServlet("/ResultServlet")
public class ResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public ResultServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void init(ServletConfig config) throws ServletException {
	}

	
	public void destroy() {
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String firstName="",lastName="",city="",state="",mobNo="",email="";
		Cookie [] cookies = request.getCookies();
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals("firstName"))
				firstName =cookie.getValue();
			else if(cookie.getName().equals("lastName"))
				lastName=cookie.getValue();
			else if(cookie.getName().equals("city"))
				city=cookie.getValue();
			else if(cookie.getName().equals("state"))
				state=cookie.getValue();
		}
		mobNo=(String)request.getParameter("mobNo");
		email=(String)request.getParameter("email");
		
		PrintWriter writer=response.getWriter();
		writer.println("<html>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("</br>");
		writer.println("<form> ");
		writer.println("<td>firstName:</td>"+firstName);
		writer.println("</br>");
		writer.println("<td>lastName:</td>"+lastName);
		writer.println("</br>");
		writer.println("<td>city:</td>"+city);
		writer.println("</br>");
		writer.println("<td>state:</td>"+state);
		writer.println("</br>");
		writer.println("<td>email:</td>"+email);
		writer.println("</br>");
		writer.println("<td>mobNo:</td>"+mobNo);
		writer.println("</form>");
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");
		}
	
	}


