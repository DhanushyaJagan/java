package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.BasicClass;

@WebServlet("/PlaceServlet")
public class PlaceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public PlaceServlet() {
        super();
    }

	
	public void init(ServletConfig config) throws ServletException {
			}

	
	public void destroy() {
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//String firstName=request.getParameter("firstName");
	//	String lastName=request.getParameter("lastName");
	//BasicClass basicClass=new BasicClass(firstName, lastName);
	//Cookie c1 = new  Cookie("firstName",basicClass.getFirstName());
	////	Cookie c2 = new Cookie("lastName" ,basicClass.getLastName());
		//response.addCookie(c1);
	//	response.addCookie(c2);
		//request.setAttribute("firstName", firstName);
		//request.setAttribute("lastName", lastName);
		//Cookie c1 = new  Cookie("firstName",firstName);
		//Cookie c2 = new Cookie("lastName" ,lastName);
		//response.addCookie(c1);
		//response.addCookie(c2);
		String firstName=(String)request.getParameter("firstName");
		String lastName=(String)request.getParameter("lastName");
		Cookie c1 = new  Cookie("firstName",firstName);
		Cookie c2 = new Cookie("lastName" ,lastName);
		response.addCookie(c1);
		response.addCookie(c2);
		PrintWriter writer=response.getWriter();
		writer.println("<html>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("</br>");

		writer.println("<form action='CommServlet' method='post'>");

		//writer.println("<table>");
		//writer.println("<tr>");
		writer.println("<td>firstName:</td>"+firstName);
		writer.println("</br>");
		//writer.println("</tr>");
		//writer.println("<tr>");
		writer.println("<td>lastName:</td>"+lastName);
		writer.println("</br>");
		//writer.println("</tr>");
		//writer.println("<tr>");
		writer.println("<td>city</td>");
		writer.println("<td><input type='text' name='city'></td>");
		writer.println("</br>");

		//writer.println("</tr>");
	//	writer.println("<tr>");
		writer.println("<td>state</td>");
		writer.println("<td><input type='text' name='state'></td>");
		writer.println("</br>");

		//writer.println("</tr>");
		//writer.println("<tr>");
		writer.println("<td><input type='submit' value='submit'></td>");
		//writer.println("</tr>");
		writer.println("</form>");
		//writer.println("</table>");
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");
		}
	}


