package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.BasicClass;

@WebServlet("/CommServlet")
public class CommServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public CommServlet() {
        super();
    }

	public void init(ServletConfig config) throws ServletException {
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	String firstName="",lastName="",city="",state="";
	Cookie [] cookies = request.getCookies();
	for (Cookie cookie : cookies) {
		if(cookie.getName().equals("firstName"))
			firstName =cookie.getValue();
		else if(cookie.getName().equals("lastName"))
			lastName=cookie.getValue();
	}
	city=(String)request.getParameter("city");
	state=(String)request.getParameter("state");
	Cookie c1 = new  Cookie("firstName",firstName);
	Cookie c2 = new Cookie("lastName" ,lastName);
	Cookie c3 = new  Cookie("city",city);
	Cookie c4 = new Cookie("state" ,state);
	response.addCookie(c1);
	response.addCookie(c2);
	response.addCookie(c3);
	response.addCookie(c4);
	
		PrintWriter writer=response.getWriter();
		writer.println("<html>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("</br>");

		writer.println("<form action='ResultServlet' method= 'post'> ");

		//writer.println("<table>");
		//writer.println("<tr>");
		writer.println("<td>firstName:</td>"+firstName);
		writer.println("</br>");
		//writer.println("</tr>");
		//writer.println("<tr>");
		writer.println("<td>lastName:</td>"+lastName);
		writer.println("</br>");
		//writer.println("</tr>");
		//writer.println("<tr>");
		
		writer.println("<td>city:</td>"+city);
		writer.println("</br>");
		writer.println("<td>state:</td>"+state);
		writer.println("</br>");
		//writer.println("</tr>");
	//	writer.println("<tr>");
		writer.println("<td>email</td>");
		writer.println("<td><input type='text' name='email'></td>");
		writer.println("</br>");

		writer.println("<td>mobNo</td>");
		writer.println("<td><input type='text' name='mobNo'></td>");
		
		//writer.println("</tr>");
		//writer.println("<tr>");
		writer.println("<td><input type='submit' value='submit'></td>");
		//writer.println("</tr>");
		writer.println("</form>");
		//writer.println("</table>");
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");
		}
	}


