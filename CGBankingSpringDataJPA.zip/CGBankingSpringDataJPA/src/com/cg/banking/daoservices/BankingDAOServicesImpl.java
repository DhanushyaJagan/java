package com.cg.banking.daoservices;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

import org.hibernate.Transaction;




import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.loader.custom.Return;
import org.springframework.beans.factory.annotation.Autowired;
                     

import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Account;
import com.cg.banking.utlility.BankingUtility;
public class BankingDAOServicesImpl implements BankingDAOServices{
	@Autowired(required=true)
	
	private  EntityManagerFactory entityManagerFactory ;
	
	Map<Integer,Customer> customers;

	@Override
	public int insertCustomer(Customer customer) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Customer customer=entityManager.find(Customer.class, customerId);
		if(customer!=null) {
			account.setCustomer(customer);
			entityManager.persist(account);
			entityManager.flush();
			entityManager.getTransaction().commit();
			entityManager.close();
			return account.getAccountNo();
		}
		return 0;
	
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		if(account.getCustomer().getCustomerId()==customerId){
		entityManager.merge(account);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
		}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		if(account.getCustomer().getCustomerId()==customerId){
			account.setPinNumber(BankingUtility.rand.nextInt(9999));
			updateAccount(customerId, account);
			return account.getPinNumber();
			}
			return 0;
	
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo,
			com.cg.banking.beans.Transaction transaction) {
			EntityManager entityManager=entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			Account account=(Account) entityManager.find(Account.class, accountNo);
				transaction.setAccount(account);
				entityManager.persist(transaction);
				entityManager.flush();
				entityManager.getTransaction().commit();
				entityManager.close();
				return true;
	}
	
	@Override
	public boolean deleteCustomer(int customerId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Customer customer=entityManager.find(Customer.class, customerId);
		if(customer!=null) {
		entityManager.getTransaction().begin();
		entityManager.remove(customer);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
		}	
		return false;

	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Account account=entityManager.find(Account.class, accountNo);
		entityManager.getTransaction().begin();
		entityManager.remove(account);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Customer getCustomer(int customerId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Customer customer=entityManager.find(Customer.class, customerId);
		return customer;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Account account=entityManager.find(Account.class, accountNo);
		if(account.getCustomer().getCustomerId()==customerId){
		return account;
		}
		return null;	
	}

	@Override
	public com.cg.banking.beans.Transaction getTransaction(int customerId,
			long accountNo, int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		TypedQuery<Customer> query = entityManager.createQuery("Select c from Customer c",Customer.class);
		return query.getResultList();
	}		

	@Override
	public List<Account> getAccounts(int customerId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		TypedQuery<Account> query = entityManager.createQuery("Select a from Account a",Account.class);
		return query.getResultList();
	}
	

	@Override
	public List<com.cg.banking.beans.Transaction> getTransactions(
			int customerId, long accountNo) {
		/*EntityManager entityManager=entityManagerFactory.createEntityManager();
		TypedQuery<Transaction> query = entityManager.createQuery("Select t from Transaction t",Transaction.class);
		return query.getResultList();*/
			return null;
	}	}

	

	
	
	
	/*@Override
	public int insertCustomer(Customer customer) {
		customers.put(BankingUtility.CUSTOMER_ID, customer);
		customer.setCustomerId(BankingUtility.CUSTOMER_ID++);
		return customer.getCustomerId();
	}
	@Override
	public long insertAccount(int customerId, Account account) {
		customers.get(customerId).getAccounts().put(BankingUtility.ACCOUNT_NO, account);
		account.setAccountNo(BankingUtility.ACCOUNT_NO++);
		return account.getAccountNo();		
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		customers.get(customerId).getAccounts().put(account.getAccountNo(), account);
		return true;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		 account.setPinNumber(BankingUtility.PIN++);
		return account.getPinNumber();
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo,
			Transaction transaction) {
		customers.get(customerId).getAccounts().get(accountNo).getTransactions().put(BankingUtility.TRANSACTION_ID, transaction);
		transaction.setTransactionId(BankingUtility.TRANSACTION_ID++);
		return true;
	}	
	@Override
	public boolean deleteCustomer(int customerId) {
		customers.remove(customerId);
		return true;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		customers.get(customerId).getAccounts().remove(accountNo);
		return true;
	}
	@Override
	public Customer getCustomer(int customerId) {
		return customers.get(customerId);
	}
	@Override
	public Account getAccount(int customerId, long accountNo) {
		return customers.get(customerId).getAccounts().get(accountNo);
	}
	@Override
	public Transaction getTransaction(int customerId, long accountNo,
			int transactionId) {
		return customers.get(customerId).getAccounts().get(accountNo).getTransactions().get(transactionId);
	}
	@Override
	public List<Customer> getCustomers() {
		List<Customer> customerlist=new ArrayList<Customer>(customers.values());
		return 	customerlist;
	}
	@Override
	public List<Account> getAccounts(int customerId) {
		List<Account> accountlist=new ArrayList<Account>(customers.get(customerId).getAccounts().values());
		return accountlist;
	}
	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		List<Transaction> transactionlist=new ArrayList<Transaction>(customers.get(customerId).getAccounts().get(accountNo).getTransactions().values());
		return transactionlist;
	}*/
	
