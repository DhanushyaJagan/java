package com.cg.banking.services;
import java.util.List;

import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Transaction;
import com.cg.banking.beans.Account;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
public class BankingServicesImpl implements BankingServices { 
	private BankingDAOServices daoservices;
	public BankingServicesImpl() {
	daoservices=new BankingDAOServicesImpl();
	}
	@Override
	public int acceptCustomerDetails(String firstName, String lastName,
			String customerEmailId, String panCard, String localAddressCity,
			String localAddressState, int localAddressPinCode,
			String homeAddressCity, String homeAddressState,
			int homeAddressPinCode) throws BankingServicesDownException {
		return daoservices.insertCustomer(new Customer(firstName, lastName,customerEmailId, panCard,new Address(localAddressPinCode, localAddressCity, localAddressState),new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
	}
	@Override
	public long openAccount(int customerId, String accountType,
			float initBalance) {
		return daoservices.insertAccount(customerId, new Account(accountType, initBalance));
	}
	@Override
	public float depositAmount(int customerId, long accountNo, float amount)throws CustomerNotFoundException,
	AccountNotFoundException,BankingServicesDownException, AccountBlockedException {
		daoservices.insertTransaction(customerId, accountNo, new Transaction(amount));
		this.getAccountDetails(customerId, accountNo).setAccountBalance(getAccountDetails(customerId, accountNo).getAccountBalance()+amount);
		getAccountDetails(customerId, accountNo).setStatus("ACTIVE");
		return this.getAccountDetails(customerId, accountNo).getAccountBalance();
	}
	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount,
			int pinNumber)throws InsufficientAmountException,CustomerNotFoundException,
			AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException ,AccountBlockedException {
		//if(pinNumber==getAccountDetails(customerId, accountNo).getPinNumber())
		//if(getAccountDetails(customerId, accountNo).getPinCounter()<3)
		//if(amount<daoservices.getAccount(customerId, accountNo).getAccountBalance())
		while(getAccountDetails(customerId, accountNo)!=null&&getAccountDetails(customerId, accountNo).getPinCounter()<3){
			if(pinNumber==getAccountDetails(customerId, accountNo).getPinNumber()) {
				if(amount<=daoservices.getAccount(customerId, accountNo).getAccountBalance()) {
					daoservices.insertTransaction(customerId, accountNo, new Transaction(amount));
					float totalBalance=this.getAccountDetails(customerId, accountNo).getAccountBalance()-amount;
					this.getAccountDetails(customerId, accountNo).setAccountBalance(totalBalance);
					getAccountDetails(customerId, accountNo).setPinCounter(0);
					return this.getAccountDetails(customerId, accountNo).getAccountBalance();
				}
				getAccountDetails(customerId, accountNo).setPinCounter(getAccountDetails(customerId, accountNo).getPinCounter()+1);
			}
			else if(getAccountDetails(customerId, accountNo).getPinCounter()>=3) {
				getAccountDetails(customerId, accountNo).setStatus("Blocked");
				return -1;
			}
			else
				return 0;
		}
		return 0;
	}
	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo,
			int customerIdFrom, long accountNoFrom, float transferAmount,
			int pinNumber) throws InsufficientAmountException,
			CustomerNotFoundException,
			AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		if(pinNumber==daoservices.getAccount(customerIdFrom, accountNoFrom).getPinNumber());
		if(transferAmount<=daoservices.getAccount(customerIdFrom, accountNoFrom).getAccountBalance());
				float totalBalanceTo=daoservices.getAccount(customerIdTo, accountNoTo).getAccountBalance()+transferAmount;
				daoservices.getAccount(customerIdTo, accountNoTo).setAccountBalance(totalBalanceTo);
				float totalBalanceFrom=daoservices.getAccount(customerIdFrom, accountNoFrom).getAccountBalance()-transferAmount;
				daoservices.getAccount(customerIdFrom, accountNoFrom).setAccountBalance(totalBalanceFrom);
				return true;		
				
	}
	@Override
	public Customer getCustomerDetails(int customerId)throws CustomerNotFoundException,BankingServicesDownException {
return daoservices.getCustomer(customerId);		
	}
	@Override
	public Account getAccountDetails(int customerId, long accountNo)throws	CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException {
		return daoservices.getAccount(customerId, accountNo);
	}
	@Override
	public int generateNewPin(int customerId, long accountNo) throws
	CustomerNotFoundException,AccountNotFoundException ,
	BankingServicesDownException{
		return daoservices.generatePin(customerId, this.getAccountDetails(customerId, accountNo));
	}
	@Override
	public boolean changeAccountPin(int customerId, long accountNo,
			int oldPinNumber, int newPinNumber)throws CustomerNotFoundException,
			AccountNotFoundException,
			InvalidPinNumberException,BankingServicesDownException  {
		if(oldPinNumber==daoservices.getAccount(customerId, accountNo).getPinNumber());
		oldPinNumber=newPinNumber;
		daoservices.getAccount(customerId, accountNo).setPinNumber(oldPinNumber);
		return true;
	}
	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException{

		return daoservices.getCustomers();
	}
	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)throws BankingServicesDownException,CustomerNotFoundException {
		return daoservices.getAccounts(customerId);
	}
	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException {
		return daoservices.getTransactions(customerId, accountNo);
	}
	@Override
	public String accountStatus(int customerId, long accountNo)	throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException, AccountBlockedException {
		return daoservices.getAccount(customerId, accountNo).getStatus();
	}
	@Override
	public boolean closeAccount(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException {
		if(daoservices.getAccount(customerId, accountNo).getAccountBalance()==0){
			daoservices.deleteAccount(customerId, accountNo);
		return true;
		}
		return false;
	}
}
