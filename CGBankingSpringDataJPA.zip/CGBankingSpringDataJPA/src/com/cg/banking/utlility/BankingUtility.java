package com.cg.banking.utlility;

import java.util.Random;

public class BankingUtility {
	public  static int CUSTOMER_ID=111;
	public  static long ACCOUNT_NO=111111;
	public static int PIN=123;
	public  static int TRANSACTION_ID=1234;
	public static Random rand=new Random();
}
